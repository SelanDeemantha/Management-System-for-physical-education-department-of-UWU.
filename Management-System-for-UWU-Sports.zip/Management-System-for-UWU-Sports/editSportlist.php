<?php

include_once 'config.php';

$sql4="UPDATE sportlist SET sportName='$_POST[sprtName]',gender='$_POST[gender]',incharge='$_POST[incharge]',coach='$_POST[coach]',captain='$_POST[captain]',viceCaptain='$_POST[viceCaptain]' where sportID='$_POST[id]'";

if(mysqli_query($con,$sql4)){

    header("refresh:1; url=sports.php");


}
else{

    echo"Not Updated";

}


?>