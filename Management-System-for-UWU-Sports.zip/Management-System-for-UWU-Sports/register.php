    <?php
session_start();

if(isset($_SESSION['usr_id'])) {
    header("Location: index.php");
}

include_once 'config.php';

$connect = mysql_connect('localhost', 'root', '');
$database = mysql_select_db('uwusports');
//set validation error flag as false
$error = false;

//check if form is submitted
if (isset($_POST['signup'])) {
    $initials = mysqli_real_escape_string($con, $_POST['initials']);
    $regno = mysqli_real_escape_string($con, $_POST['regno']);
    $gender = mysqli_real_escape_string($con, $_POST['options']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $address = mysqli_real_escape_string($con, $_POST['address']);
    $tel = mysqli_real_escape_string($con, $_POST['tel']);
    $type = mysqli_real_escape_string($con, $_POST['selectType']);
    $username = mysqli_real_escape_string($con, $_POST['username']);
    $password = mysqli_real_escape_string($con, $_POST['password']);
    $cpassword = mysqli_real_escape_string($con, $_POST['confirm']);

    $dob = mysqli_real_escape_string($con, $_POST['DOB']);
    $acyear = mysqli_real_escape_string($con, $_POST['acYear']);
    $sport1 = mysqli_real_escape_string($con, $_POST['selectSport1']);
    $sport2 = mysqli_real_escape_string($con, $_POST['selectSport2']);
    $sport3 = mysqli_real_escape_string($con, $_POST['selectSport3']);   
    $acive = mysqli_real_escape_string($con, $_POST['ach']);
    $startdate = mysqli_real_escape_string($con, $_POST['SD']);
   


    //name can contain only alpha characters and space
    if (!preg_match("/^[a-zA-Z ]+$/",$initials)) {
        $error = true;
        $name_error = "Name must contain only alphabets and space";
    }
    if(!filter_var($email,FILTER_VALIDATE_EMAIL)) {
        $error = true;
        $email_error = "Please Enter Valid Email ID";
    }
    if (isset($username)) {
        $mysql_get_users = mysql_query("SELECT * FROM user where username='$username'");

        $get_rows = mysql_affected_rows($connect);

        if ($get_rows >= 1) {
            $error = true;
            $username_error = "Username Is Already Exsist ";
            //echo "user exists";
            //die();
        }

    }
    if(strlen($password) < 6) {
        $error = true;
        $password_error = "Password must be minimum of 6 characters";
    }
    if($password != $cpassword) {
        $error = true;
        $cpassword_error = "Password and Confirm Password doesn't match";
    }
    if (!$error) {
        if(mysqli_query($con, "INSERT INTO users(initials,gender,email,address,tel,type,username,password,regDate) VALUES('" . $initials . "','".$gender."','".$email."','".$address."','".$tel."','".$type."','".$username."', '" . md5($password) . "','".$startdate."')")) {
            
            $last_id = $con->insert_id;
            $_SESSION['last_id'] = $last_id;
            
            $result = mysqli_query($con, "INSERT INTO student(auto_id,studentname,regno,gender,dob,address,number,acyr,sport1,sport2,sport3,achivements,startdate) VALUES('" . $last_id . "','" . $initials . "','" . $regno . "','" . $gender . "','" . $dob . "','" . $address . "','" . $tel . "','" . $acyear . "','" . $sport1 . "','" . $sport2 . "','" . $sport3 . "','" . $acive . "','" . $startdate . "')");
            $successmsg = "Successfully Registered!&nbsp;<a href='login.php'>Click here to Login</a>";

            include_once 'config.php';

            $records = mysqli_query($con, "SELECT * FROM student");

            if ($row = mysqli_fetch_array($records)) {

                $_SESSION['autoid'] = $row['auto_id'];
            }
        } else {
            $errormsg = "Error!!!&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href= 'register.php' style='font-weight: bold'>Click here to Try Again</a>";
        }
    }

if($error = '') {
     if (array_key_exists('tel', $_POST)) {
         if (!preg_match('/^[0-9]{3}-[0-9]{3}-[0-9]{4}$/', $_POST['tel'])) {
             $error = 'Invalid Number!';
         }
     }
 }



}
?>





<!DOCTYPE html>
<html lang="en">
<head>

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css">
    <link rel="stylesheet" href="style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <!--script src="js/jquery.min.js"></script-->
    <link href="//cdnjs.cloudflare.com/ajax/libs/animate.css/3.1.0/animate.min.css" rel="stylesheet"/>
    <script src="js/jquery.validate.min.js"></script>

    


    <title>Register</title>
</head>
<body class="home" onload="load()">
    <div  id="header1" style="width: 1350px;margin: 0 auto;background-color : black;height: 133px;padding-top: 10px;">
		<div id="logo">
                    <a href="index.php"> <img src="img/logo.jpg" alt="LOGO" style="width: 200px ;height: 115px;float: right;"> </a>
		</div>
		<ul id="navigation">
			
			
		</ul>
	</div>
<div class="container">
<div class="row main">
<div class="col-md-3"></div>
<div class="col-md-6">

    <div style="padding-bottom: 10px;padding-top: 3px;text-align: center" class="main-login main-center">
        <h3>Create A New Account</h3>
    </div>
    <br><br>

    <ul class="nav nav-tabs">
        <li class="active"><a data-toggle="tab" href="#student">Student</a> </li>
        <li><a data-toggle="tab" href="#coach">Coach</a></li>
        <li><a data-toggle="tab" href="#staff">Staff</a></li>
        <li><a data-toggle="tab" href="#admin">Admin</a></li>
    </ul>
    <br>

    <div class="tab-content">

        <div id="student" class="tab-pane fade in active">
        <form role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="signup">

        <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Name with initials</label>
            <div class="cols-sm-10">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
                    <input type="text" name="initials" id="initials"  placeholder="Enter your Name with initials" required value="<?php if($error) echo $initials; ?>" class="form-control" />

                </div>
                <span class="text-danger" style="color: black; font-family: Arial;"><?php if (isset($name_error)) echo $name_error; ?></span>
            </div>
        </div>

        <div class="form-group">
            <label class="name" class="cols-sm-2 control-label">Registration number</label>
            <div class="cols-sm-10">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
                    <input type="text" pattern="^[A-Za-z][A-Za-z][A-Za-z][/][A-Za-z][A-Za-z][A-Za-z][/][0-9][0-9][/][0-9][0-9][0-9][0-9]*$" title="Please Enter Valied Reg Number" class="form-control" name="regno" id="regno"  placeholder="UWU/DEG/XX/00XX"/>
                </div>


            </div>
        </div>



        <div class="form-group">
            <label class="name" class="cols-sm-2 control-label">Gender</label>
            <div class="cols-sm-10">

                <div class="btn-group" data-toggle="buttons">
                    <label class="btn btn-primary">
                        <input  type="radio" name="options" id="option2" autocomplete="off" value="Male"> Male
                    </label>
                    <label class="btn btn-primary">
                        <input  type="radio" name="options" id="option3" autocomplete="off" value="Female"> Female
                    </label>


                </div>
            </div>
        </div>




        <div class="form-group">
            <label class="email" class="cols-sm-2 control-label">Your Email</label>
            <div class="cols-sm-10">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-envelope fa" aria-hidden="true"></i></span>
                    <input type="text"  name="email" id="email"  placeholder="Enter your Email" required value="<?php if($error) echo $email; ?>" class="form-control"/>

                </div>
                <span class="text-danger" style="color: black;font-family: Arial;"><?php if (isset($email_error)) echo $email_error; ?></span>
            </div>
        </div>

        <div class="form-group">
            <label class="email" class="cols-sm-2 control-label">Your Address</label>
            <div class="cols-sm-10">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-home" aria-hidden="true"></i></span>
                    <input type="text" class="form-control" name="address" id="address"  placeholder="Enter your Address"/>
                </div>
            </div>
        </div>


        <div class="form-group">
            <label class="email" class="cols-sm-2 control-label">Contact Number</label>
            <div class="cols-sm-10">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-phone" aria-hidden="true"></i></span>
                    <input type="text" pattern="[0-9]{10}" title="Please Enter Valied Number" class="form-control" name="tel" id="tel"  placeholder="Enter your Contact Number"/>
                </div>

                <span class="warning" style="color: black;font-family: Arial;"> <?php echo $error; ?></span>
            </div>
        </div>



        <div class="form-group">
            <label class="email" class="cols-sm-2 control-label">Select Type</label>
            <div class="cols-sm-10">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-home" aria-hidden="true"></i></span>
                    <select class="form-control" placeholder="Select Type"  name="selectType" id="selectType">
                        <option disabled>--Select--</option>
                        <option>Student</option>
                        <option>Coach</option>
                        <option>Staff</option>
                        <option>Admin</option>
                    </select>
                </div>
            </div>
        </div>


        <script>

            function load() {
                document.getElementById("selectType").selectedIndex = 0;

            }
        </script>










        <div class="form-group">
            <label class="email" class="cols-sm-2 control-label"><br>Academic Year</label>
            <div class="cols-sm-10">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-home" aria-hidden="true"></i></span>
                    <input type="text" class="form-control" name="acYear" id="acYear"  placeholder="Academic Year"/>
                </div>
            </div>
        </div>


        <div class="form-group">
            <label class="email" class="cols-sm-2 control-label">Date of Birth</label>
            <div class="cols-sm-10">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-home" aria-hidden="true"></i></span>
                    <input type="date" class="form-control" name="DOB" id="DOB"  placeholder=""/>
                </div>
            </div>
        </div>

        <div class="form-group">
            <label class="email" class="cols-sm-2 control-label">Select Sport 1</label>
            <div class="cols-sm-10">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-home" aria-hidden="true"></i></span>
                    <select class="form-control"  placeholder="Sport 1"  name="selectSport1" id="selectSport1">
                        <option></option>
                        <option>Badminton</option>
                        <option>Baseball</option>
                        <option>Basketball</option>
                        <option>Chess</option>
                        <option>Cricket</option>
                        <option>Elle</option>
                        <option>Football</option>
                        <option>Hockey</option>
                        <option>Karate</option>
                        <option>Netball</option>
                        <option>Rugby</option>
                        <option>Swimming</option>
                        <option>Table Tennis</option>
                        <option>Taekwondo</option>
                        <option>Tennis</option>
                        <option>Track and Field</option>
                        <option>Volleyball</option>
                        <option>Weight Lifting</option>
                    </select>
                </div>
            </div>
        </div>



        <div class="form-group">
            <label class="email" class="cols-sm-2 control-label">Select Sport 2</label>
            <div class="cols-sm-10">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-home" aria-hidden="true"></i></span>
                    <select class="form-control"  placeholder="Sport 2"  name="selectSport2" id="selectSport2">
                        <option></option>
                        <option>Badminton</option>
                        <option>Baseball</option>
                        <option>Basketball</option>
                        <option>Chess</option>
                        <option>Cricket</option>
                        <option>Elle</option>
                        <option>Football</option>
                        <option>Hockey</option>
                        <option>Karate</option>
                        <option>Netball</option>
                        <option>Rugby</option>
                        <option>Swimming</option>
                        <option>Table Tennis</option>
                        <option>Taekwondo</option>
                        <option>Tennis</option>
                        <option>Track and Field</option>
                        <option>Volleyball</option>
                        <option>Weight Lifting</option>
                    </select>
                </div>
            </div>
        </div>

        <div class="form-group">
            <label class="email" class="cols-sm-2 control-label">Select Sport 3</label>
            <div class="cols-sm-10">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-home" aria-hidden="true"></i></span>
                    <select class="form-control"  placeholder="Sport 3"  name="selectSport3" id="selectSport3">
                        <option></option>
                        <option>Badminton</option>
                        <option>Baseball</option>
                        <option>Basketball</option>
                        <option>Chess</option>
                        <option>Cricket</option>
                        <option>Elle</option>
                        <option>Football</option>
                        <option>Hockey</option>
                        <option>Karate</option>
                        <option>Netball</option>
                        <option>Rugby</option>
                        <option>Swimming</option>
                        <option>Table Tennis</option>
                        <option>Taekwondo</option>
                        <option>Tennis</option>
                        <option>Track and Field</option>
                        <option>Volleyball</option>
                        <option>Weight Lifting</option>
                    </select>
                </div>
            </div>
        </div>

        <div class="form-group">
            <label class="email" class="cols-sm-2 control-label">Achivements</label>
            <div class="cols-sm-10">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-home" aria-hidden="true"></i></span>
                    <input type="text" class="form-control" name="ach" id="ach"  placeholder="Achivements"/>
                </div>
            </div>
        </div>

        <div class="form-group">
            <label class="email" class="cols-sm-2 control-label">Registration Date</label>
            <div class="cols-sm-10">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-home" aria-hidden="true"></i></span>
                    <input type="date" class="form-control" name="SD" id="SD"  placeholder=""/>
                </div>
            </div>
        </div>



        <div class="form-group">
            <label class="username" class="cols-sm-2 control-label">Username</label>
            <div class="cols-sm-10">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-users fa" aria-hidden="true"></i></span>
                    <input type="text" class="form-control" name="username" id="username"  placeholder="Enter your Username" required value="<?php if($error) echo $usernmae; ?>"/>
                </div>
                <span class="text-danger" style="color: black; font-family: Arial;"><?php if (isset($username_error)) echo $username_error  ?></span>
            </div>
        </div>


        <div class="form-group">
            <label class="password" class="cols-sm-2 control-label">Password</label>
            <div class="cols-sm-10">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
                    <input type="password"  name="password" id="password"  placeholder="Enter your Password" required class="form-control"/>
                </div>
                <span class="text-danger" style="color: black;font-family: Arial;"><?php if (isset($password_error)) echo $password_error; ?></span>
            </div>
        </div>


        <div class="form-group">
            <label class="confirm" class="cols-sm-2 control-label">Confirm Password</label>
            <div class="cols-sm-10">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
                    <input type="password" class="form-control" name="confirm" id="confirm"  placeholder="Confirm your Password"/>
                </div>
                <span class="text-danger" style="color: black; font-family: Arial;"><?php if (isset($cpassword_error)) echo $cpassword_error; ?></span>
            </div>
        </div>

        <div class="form-group ">
            <!--   <a href="register.php" target="_blank" type="button" id="button" class="btn btn-primary btn-lg btn-block login-button">Register</a> -->

            <input type="submit" style="align-items: center;" name="signup" value="Sign Up" class="btn btn-primary" placeholder="Register" />
        </div>


        <div class="form-group">
            <label class="confirm" class="cols-sm-2 control-label">Already Registered?<a href="login.php"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Login Here</a></label>
            <div class="cols-sm-10">
            </div>
        </div>







        </form>
        </div>

        <div id="coach" class="tab-pane fade">
            <form role="form" action="stu-reg-coach.php" method="post" name="signup">

                <div class="form-group">
                    <label for="name" class="cols-sm-2 control-label">Name with initials</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
                            <input type="text" name="initials" id="initials"  placeholder="Enter your Name with initials" required value="<?php if($error) echo $initials; ?>" class="form-control" />

                        </div>
                        <span class="text-danger" style="color: black; font-family: Arial;"><?php if (isset($name_error)) echo $name_error; ?></span>
                    </div>
                </div>




                <div class="form-group">
                    <label class="name" class="cols-sm-2 control-label">Gender</label>
                    <div class="cols-sm-10">

                        <div class="btn-group" data-toggle="buttons">
                            <label class="btn btn-primary">
                                <input  type="radio" name="options" id="option2" autocomplete="off" value="Male"> Male
                            </label>
                            <label class="btn btn-primary">
                                <input  type="radio" name="options" id="option3" autocomplete="off" value="Female"> Female
                            </label>


                        </div>
                    </div>
                </div>




                <div class="form-group">
                    <label class="email" class="cols-sm-2 control-label">Your Email</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-envelope fa" aria-hidden="true"></i></span>
                            <input type="text"  name="email" id="email"  placeholder="Enter your Email" required value="<?php if($error) echo $email; ?>" class="form-control"/>

                        </div>
                        <span class="text-danger" style="color: black;font-family: Arial;"><?php if (isset($email_error)) echo $email_error; ?></span>
                    </div>
                </div>

                <div class="form-group">
                    <label class="email" class="cols-sm-2 control-label">Your Address</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-home" aria-hidden="true"></i></span>
                            <input type="text" class="form-control" name="address" id="address"  placeholder="Enter your Address"/>
                        </div>
                    </div>
                </div>


                <div class="form-group">
                    <label class="email" class="cols-sm-2 control-label">Contact Number</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-phone" aria-hidden="true"></i></span>
                            <input type="text" pattern="[0-9]{10}" title="Please Enter Valied Number" class="form-control" name="tel" id="tel"  placeholder="Enter your Contact Number"/>
                        </div>

                        <span class="warning" style="color: black;font-family: Arial;"> <?php echo $error; ?></span>
                    </div>
                </div>


                <div class="form-group">
                    <label class="email" class="cols-sm-2 control-label">Select Type</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-home" aria-hidden="true"></i></span>
                            <select class="form-control" placeholder="Select Type"  name="selectType" id="selectType">
                                <option disabled>--Select--</option>
                                <option>Student</option>
                                <option>Coach</option>
                                <option>Staff</option>
                                <option>Admin</option>
                            </select>
                        </div>
                    </div>
                </div>


                <script>

                    function load() {
                        document.getElementById("selectType").selectedIndex = 0;
                    }
                </script>

<div class="form-group">
            <label class="email" class="cols-sm-2 control-label">Registration Date</label>
            <div class="cols-sm-10">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-home" aria-hidden="true"></i></span>
                    <input type="date" class="form-control" name="SD" id="SD"  placeholder=""/>
                </div>
            </div>
        </div>




                <div class="form-group">
                    <label class="username" class="cols-sm-2 control-label">Username</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-users fa" aria-hidden="true"></i></span>
                            <input type="text" class="form-control" name="username" id="username"  placeholder="Enter your Username"/>
                        </div>
                        <span class="text-danger" style="color: black; font-family: Arial;"><?php if (isset($username_error)) echo $username_error  ?></span>
                    </div>
                </div>

                <div class="form-group">
                    <label class="password" class="cols-sm-2 control-label">Password</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
                            <input type="password"  name="password" id="password"  placeholder="Enter your Password" required class="form-control"/>
                        </div>
                        <span class="text-danger" style="color: black;font-family: Arial;"><?php if (isset($password_error)) echo $password_error; ?></span>
                    </div>
                </div>

                <div class="form-group">
                    <label class="confirm" class="cols-sm-2 control-label">Confirm Password</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
                            <input type="password" class="form-control" name="confirm" id="confirm"  placeholder="Confirm your Password"/>
                        </div>
                        <span class="text-danger" style="color: black; font-family: Arial;"><?php if (isset($cpassword_error)) echo $cpassword_error; ?></span>
                    </div>
                </div>

                <div class="form-group ">
                    <!--   <a href="register.php" target="_blank" type="button" id="button" class="btn btn-primary btn-lg btn-block login-button">Register</a> -->

                    <input type="submit" style="align-items: center;" name="signup" value="Sign Up" class="btn btn-primary" placeholder="Register" />
                </div>


                <div class="form-group">
                    <label class="confirm" class="cols-sm-2 control-label">Already Registered?<a href="login.php"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Login Here</a></label>
                    <div class="cols-sm-10">
                    </div>
                </div>



            </form>
        </div>

        <div id="staff" class="tab-pane fade">
            <form role="form" action="stu-reg-staff.php" method="post" name="signup">

                <div class="form-group">
                    <label for="name" class="cols-sm-2 control-label">Name with initials</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
                            <input type="text" name="initials" id="initials"  placeholder="Enter your Name with initials" required value="<?php if($error) echo $initials; ?>" class="form-control" />

                        </div>
                        <span class="text-danger" style="color: black; font-family: Arial;"><?php if (isset($name_error)) echo $name_error; ?></span>
                    </div>
                </div>




                <div class="form-group">
                    <label class="name" class="cols-sm-2 control-label">Gender</label>
                    <div class="cols-sm-10">

                        <div class="btn-group" data-toggle="buttons">
                            <label class="btn btn-primary">
                                <input  type="radio" name="options" id="option2" autocomplete="off" value="Male"> Male
                            </label>
                            <label class="btn btn-primary">
                                <input  type="radio" name="options" id="option3" autocomplete="off" value="Female"> Female
                            </label>


                        </div>
                    </div>
                </div>




                <div class="form-group">
                    <label class="email" class="cols-sm-2 control-label">Your Email</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-envelope fa" aria-hidden="true"></i></span>
                            <input type="text"  name="email" id="email"  placeholder="Enter your Email" required value="<?php if($error) echo $email; ?>" class="form-control"/>

                        </div>
                        <span class="text-danger" style="color: black;font-family: Arial;"><?php if (isset($email_error)) echo $email_error; ?></span>
                    </div>
                </div>

                <div class="form-group">
                    <label class="email" class="cols-sm-2 control-label">Your Address</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-home" aria-hidden="true"></i></span>
                            <input type="text" class="form-control" name="address" id="address"  placeholder="Enter your Address"/>
                        </div>
                    </div>
                </div>


                <div class="form-group">
                    <label class="email" class="cols-sm-2 control-label">Contact Number</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-phone" aria-hidden="true"></i></span>
                            <input type="text" pattern="[0-9]{10}" title="Please Enter Valied Number" class="form-control" name="tel" id="tel"  placeholder="Enter your Contact Number"/>
                        </div>

                        <span class="warning" style="color: black;font-family: Arial;"> <?php echo $error; ?></span>
                    </div>
                </div>


                <div class="form-group">
                    <label class="email" class="cols-sm-2 control-label">Select Type</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-home" aria-hidden="true"></i></span>
                            <select class="form-control" placeholder="Select Type"  name="selectType" id="selectType">
                                <option disabled>--Select--</option>
                                <option>Student</option>
                                <option>Coach</option>
                                <option>Staff</option>
                                <option>Admin</option>
                            </select>
                        </div>
                    </div>
                </div>


                <script>

                    function load() {
                        document.getElementById("selectType").selectedIndex = 0;
                    }
                </script>


<div class="form-group">
            <label class="email" class="cols-sm-2 control-label">Registration Date</label>
            <div class="cols-sm-10">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-home" aria-hidden="true"></i></span>
                    <input type="date" class="form-control" name="SD" id="SD"  placeholder=""/>
                </div>
            </div>
        </div>



                <div class="form-group">
                    <label class="username" class="cols-sm-2 control-label">Username</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-users fa" aria-hidden="true"></i></span>
                            <input type="text" class="form-control" name="username" id="username"  placeholder="Enter your Username"/>
                        </div>
                        <span class="text-danger" style="color: black; font-family: Arial;"><?php if (isset($username_error)) echo $username_error  ?></span>
                    </div>
                </div>

                <div class="form-group">
                    <label class="password" class="cols-sm-2 control-label">Password</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
                            <input type="password"  name="password" id="password"  placeholder="Enter your Password" required class="form-control"/>
                        </div>
                        <span class="text-danger" style="color: black;font-family: Arial;"><?php if (isset($password_error)) echo $password_error; ?></span>
                    </div>
                </div>

                <div class="form-group">
                    <label class="confirm" class="cols-sm-2 control-label">Confirm Password</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
                            <input type="password" class="form-control" name="confirm" id="confirm"  placeholder="Confirm your Password"/>
                        </div>
                        <span class="text-danger" style="color: black; font-family: Arial;"><?php if (isset($cpassword_error)) echo $cpassword_error; ?></span>
                    </div>
                </div>

                <div class="form-group ">
                    <!--   <a href="register.php" target="_blank" type="button" id="button" class="btn btn-primary btn-lg btn-block login-button">Register</a> -->

                    <input type="submit" style="align-items: center;" name="signup" value="Sign Up" class="btn btn-primary" placeholder="Register" />
                </div>


                <div class="form-group">
                    <label class="confirm" class="cols-sm-2 control-label">Already Registered?<a href="login.php"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Login Here</a></label>
                    <div class="cols-sm-10">
                    </div>
                </div>



            </form>

        </div>

        <div id="admin" class="tab-pane fade">
            <form role="form" action="stu-reg-admin.php" method="post" name="signup">

                <div class="form-group">
                    <label for="name" class="cols-sm-2 control-label">Name with initials</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
                            <input type="text" name="initials" id="initials"  placeholder="Enter your Name with initials" required value="<?php if($error) echo $initials; ?>" class="form-control" />

                        </div>
                        <span class="text-danger" style="color: black; font-family: Arial;"><?php if (isset($name_error)) echo $name_error; ?></span>
                    </div>
                </div>




                <div class="form-group">
                    <label class="name" class="cols-sm-2 control-label">Gender</label>
                    <div class="cols-sm-10">

                        <div class="btn-group" data-toggle="buttons">
                            <label class="btn btn-primary">
                                <input  type="radio" name="options" id="option2" autocomplete="off" value="Male"> Male
                            </label>
                            <label class="btn btn-primary">
                                <input  type="radio" name="options" id="option3" autocomplete="off" value="Female"> Female
                            </label>


                        </div>
                    </div>
                </div>




                <div class="form-group">
                    <label class="email" class="cols-sm-2 control-label">Your Email</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-envelope fa" aria-hidden="true"></i></span>
                            <input type="text"  name="email" id="email"  placeholder="Enter your Email" required value="<?php if($error) echo $email; ?>" class="form-control"/>

                        </div>
                        <span class="text-danger" style="color: black;font-family: Arial;"><?php if (isset($email_error)) echo $email_error; ?></span>
                    </div>
                </div>

                <div class="form-group">
                    <label class="email" class="cols-sm-2 control-label">Your Address</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-home" aria-hidden="true"></i></span>
                            <input type="text" class="form-control" name="address" id="address"  placeholder="Enter your Address"/>
                        </div>
                    </div>
                </div>


                <div class="form-group">
                    <label class="email" class="cols-sm-2 control-label">Contact Number</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-phone" aria-hidden="true"></i></span>
                            <input type="text" pattern="[0-9]{10}" title="Please Enter Valied Number" class="form-control" name="tel" id="tel"  placeholder="Enter your Contact Number"/>
                        </div>

                        <span class="warning" style="color: black;font-family: Arial;"> <?php echo $error; ?></span>
                    </div>
                </div>


                <div class="form-group">
                    <label class="email" class="cols-sm-2 control-label">Select Type</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-home" aria-hidden="true"></i></span>
                            <select class="form-control" placeholder="Select Type"  name="selectType" id="selectType">
                                <option disabled>--Select--</option>
                                <option>Student</option>
                                <option>Coach</option>
                                <option>Staff</option>
                                <option>Admin</option>
                            </select>
                        </div>
                    </div>
                </div>


                <script>

                    function load() {
                        document.getElementById("selectType").selectedIndex = 0;
                    }
                </script>

<div class="form-group">
            <label class="email" class="cols-sm-2 control-label">Registration Date</label>
            <div class="cols-sm-10">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-home" aria-hidden="true"></i></span>
                    <input type="date" class="form-control" name="SD" id="SD"  placeholder=""/>
                </div>
            </div>
        </div>




                <div class="form-group">
                    <label class="username" class="cols-sm-2 control-label">Username</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-users fa" aria-hidden="true"></i></span>
                            <input type="text" class="form-control" name="username" id="username"  placeholder="Enter your Username"/>
                        </div>
                        <span class="text-danger" style="color: black; font-family: Arial;"><?php if (isset($username_error)) echo $username_error  ?></span>
                    </div>
                </div>

                <div class="form-group">
                    <label class="password" class="cols-sm-2 control-label">Password</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
                            <input type="password"  name="password" id="password"  placeholder="Enter your Password" required class="form-control"/>
                        </div>
                        <span class="text-danger" style="color: black;font-family: Arial;"><?php if (isset($password_error)) echo $password_error; ?></span>
                    </div>
                </div>

                <div class="form-group">
                    <label class="confirm" class="cols-sm-2 control-label">Confirm Password</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
                            <input type="password" class="form-control" name="confirm" id="confirm"  placeholder="Confirm your Password"/>
                        </div>
                        <span class="text-danger" style="color: black; font-family: Arial;"><?php if (isset($cpassword_error)) echo $cpassword_error; ?></span>
                    </div>
                </div>

                <div class="form-group ">
                    <!--   <a href="register.php" target="_blank" type="button" id="button" class="btn btn-primary btn-lg btn-block login-button">Register</a> -->

                    <input type="submit" style="align-items: center;" name="signup" value="Sign Up" class="btn btn-primary" placeholder="Register" />
                </div>


                <div class="form-group">
                    <label class="confirm" class="cols-sm-2 control-label">Already Registered?<a href="login.php"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Login Here</a></label>
                    <div class="cols-sm-10">
                    </div>
                </div>



            </form>

        </div>


    </div>

<span class="text-success" style="color: black; font-family: Arial; font-size: 20px"><?php if (isset($successmsg)) {
        echo $successmsg;
    } ?></span>
        <span class="text-danger" style="color: black; font-family: Arial; font-size: 22px"><?php if (isset($errormsg)) {
                echo $errormsg;
            } ?></span>






</div>
<div class="col-md-3"></div>



</div>


<!-- <div class="row">
     <div class="col-md-4 col-md-offset-4 text-center">
         Already Registered? <a href="login.php">Login Here</a>
     </div>
-->

</div>


<div id="footer1" style="width: 1350px;margin: 0 auto;"> 
		<ul id="connect">
			<li>
				<a href="http://facebook.com" target="_blank" class="facebook" title="Facebook"></a>
			</li>
			<li>
				<a href="http://twitter.com" target="_blank" class="twitter" title="Twitter"></a>
			</li>
			
			<li>
				<a href="http://googleplus.com" target="_blank" class="googleplus" title="Google+"></a>
			</li>
		</ul>
		<div id="footnote">
			<ul>
				<li>
                                    <a href="index.php">Home</a>
				</li>
				
			</ul>
			<span>&copy; Copyright &copy; 2017. UWU SPORTS. All rights reserved.</span>
		</div>
	</div></body>
</html>