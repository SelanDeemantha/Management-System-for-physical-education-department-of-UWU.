
<!DOCTYPE html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>SPORTS</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/dashbord.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/search.css">
    <script src="js/jquery.min.js"></script>
</head>
<body class="home" onload="lo1(),lo2()">
<header style="background-color: black">
    <div class="container clearfix">
        <a href="index.php"> <img src="img/logo.jpg" width="175" height="120"  class="hidden-xs hidden-sm"></a>
        <ul class="nav navbar-nav navbar-right">
            <li class="dropdown" style="width: 160px; text-align: center">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button">
                    Logout<span class="caret"></span>
                </a>
                <div class="dropdown-menu" id="formLogin"  style="width: 20px">
                    <div class="row">
                        <div class="container-fluid" >
                            <form action="logout.php" method="POST">

                                <li>
                                    <button type="submit" id="btnLogin" class="btn btn-success btn-sm" style="display: block; margin: 0 auto" name="lout" value="Log Out"> Log Out </button>

                                </li>
                            </form>
                        </div>
                    </div>
                </div>
            </li>

        </ul>
    </div>
</header>
<div class="container-fluid display-table">

    <div class="row display-table-row" style="background-image: url('t.jpg');background-size: cover">
        <div class="col-md-2 col-sm-1 hidden-xs display-table-cell v-align box" id="navigation">

            <div class="navi">
                 <ul>
                    <li>
                        <a href="admin.php">
                            <i class="fa fa-home" aria-hidden="true"></i>
                            <span class="hidden-xs hidden-sm">Admin Home</span></a>
                    </li>
                    
                    
                    <script>
                function myFunction2() {
                    
                    $("#notifyDiv").load("admin-notif.php");
                }
            </script>
                    <li>
                        <a href="addnotice.php">
                            <i class="fa fa-tasks" aria-hidden="true"></i>
                            <span class="hidden-xs hidden-sm">Add a notice</span></a>
                    </li>
<li>
                        <a href="addnews.php">
                            <i class="fa fa-tasks" aria-hidden="true"></i>
                            <span class="hidden-xs hidden-sm">Add a news</span></a>
                    </li>
                    <li>
                        <a href="sports.php">
                            <i class="fa fa-tasks" aria-hidden="true"></i>
                            <span class="hidden-xs hidden-sm">Sports</span></a>
                    </li>
                    <li>
                        <a href="fitnes.php" >
                            <i class="fa fa-tasks" aria-hidden="true"></i>
                            <span class="hidden-xs hidden-sm">Fitness Center</span></a>
                    </li>
                    <li>
                        <a href="groundAllo.php">
                            <i class="fa fa-tasks" aria-hidden="true"></i>
                            <span class="hidden-xs hidden-sm">Ground Allocation</span></a>
                    </li>
                    <li>
                        <a href="inventory.html">
                            <i class="fa fa-tasks" aria-hidden="true"></i>
                            <span class="hidden-xs hidden-sm">Inventory</span></a>
                    </li>

                </ul>
            </div>
        </div>
        <div  class="col-md-10 col-sm-11 display-table-cell v-align"><br><br>
            <div class="form-group" style="width:700px">
                &nbsp;&nbsp;&nbsp;<label>Select Sport</label>
                <!--<input class="form-control" type="text" style="border-color: black" name="selectSport" id="selectSport" value="">-->
                &nbsp;&nbsp;&nbsp;<select class="form-control"   style="border-color: black" name="selectSport" id="selectSport">
                    <option disabled>--Sport--</option>
                    <option>Badminton</option>
                    <option>Baseball</option>
                    <option>Basketball</option>
                    <option>Chess</option>
                    <option>Cricket</option>
                    <option>Elle</option>
                    <option>Football</option>
                    <option>Hockey</option>
                    <option>Karate</option>
                    <option>Netball</option>
                    <option>Rugby</option>
                    <option>Swimming</option>
                    <option>Table Tennis</option>
                    <option>Taekwondo</option>
                    <option>Tennis</option>
                    <option>Track and Field</option>
                    <option>Volleyball</option>
                    <option>Weight Lifting</option>
                </select>
                <script>
                    function lo1(){
                        document.getElementById('selectSport').selectedIndex =0;
                    }
                </script>
            </div>
            <div class="form-group" style="width:700px">
                &nbsp;&nbsp;&nbsp;<label>Select Gender</label>
                <!--<input class="form-control" type="text" style="border-color: black" name="selectGender" id="selectGender" value="">-->
                &nbsp;&nbsp;&nbsp;<select class="form-control"   style="border-color: black" name="selectGender" id="selectGender">
                    <option>--Gender--</option>
                    <option>Male</option>
                    <option>Female</option>
                </select>
                <script>
                    function lo2(){
                        document.getElementById('selectGender').selectedIndex =0;
                    }
                </script>
            </div>

            &nbsp;&nbsp;&nbsp;<button onclick="myFunction()" id="btnLogin" class="" name="sportSubmit" value="">Submit</button><br><br><br>
            <div id="sportDiv"></div>
            <a href="getSportList.php">Sport List</a>
            <script>
                function myFunction() {

                    var sptinfo = {
                        selSport : document.getElementById('selectSport').value,
                        selGender : document.getElementById('selectGender').value
                    };
                    $("#sportDiv").load("getSport.php", sptinfo);
                }
                
            </script>
            <div id="sportDiv"></div>
            <div id="sportListDiv"></div>
        <div class="user-dashboard"></div>
    </div>
</div>


</div>





<script src="js/jquery-3.1.1.js"></script>
<script src="js/bootstrap.js"></script>



</body>
</html>
