<?php
session_start();

$_SESSION['usr_id'];
?>
<!DOCTYPE html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Stu-BMI</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/dashbord.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/search.css">
    <link rel="stylesheet" type="text/css" href="css/student-style.css" >
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>




    <script language="JavaScript">
        <!--
        function calculateBmi() {
            var weight = document.bmiForm.weight.value
            var height = document.bmiForm.height.value
            if(weight > 0 && height > 0){
                var finalBmi = weight/(height/100*height/100)
                document.bmiForm.bmi.value = finalBmi
                if(finalBmi < 18.5){
                    document.bmiForm.meaning.value = "That you are too thin.[Under_Weight]"
                }
                if(finalBmi > 18.5 && finalBmi < 25){
                    document.bmiForm.meaning.value = "That you are health.[Normal]"
                }
                if(finalBmi > 25){
                    document.bmiForm.meaning.value = "That you have overweight.[Over_Weight]"
                }
            }
            else{
                alert("Please Fill in everything correctly")
            }
        }
        //-->
    </script>











</head>

<body class="home" onload="load1(),load2()">


<header style="background-color: black">
    <div class="container clearfix">
        <img src="img/logo.jpg" width="175" height="120"  class="hidden-xs hidden-sm">
        <ul class="nav navbar-nav navbar-right">
            <li class="dropdown" style="width: 160px; text-align: center">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button">
                    Logout<span class="caret"></span>
                </a>
                <div class="dropdown-menu" id="formLogin"  style="width: 20px">
                    <div class="row">
                        <div class="container-fluid" >
                            <form action="logout.php" method="POST">

                                <li>
                                    <button type="submit" id="btnLogin" class="btn btn-success btn-sm" style="display: block; margin: 0 auto" name="lout" value="Log Out"> Log Out </button>

                                </li>
                            </form>
                        </div>
                    </div>
                </div>
            </li>

        </ul>
    </div>
</header>



<div class="row">
    <div class="col-lg-3" style=" width:250px;  height:500px;  background:#1A8DA9;">

        <ul >
            <li class="backg-list"><a href="fitnes.php">fitnes_Home</a></li>
            <li class="backg-list"><a href="stu-edit.php">Edit_Profile</a></li>
            <li class="backg-list"><a href="stu-notification.php">Notification</a></li>
            <li class="backg-list"><a href="stu-tweets.php">Tweet</a></li>
            <li class="backg-list"><a href="fit-bmi.php">My_BMI</a></li>
            <li class="backg-list"><a href="stu-news.php">News</a></li>
        </ul>

    </div>
    <div class="col-lg-4">



        <div style="border: 4" sty class="row text-center">

            <h3 style="color: #009edf;float: left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Check your BMI </h3></br>
            </br></br></br>

            <div class="col-md-12 col-sm-12 icon-big" >


                <form name="bmiForm" role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">


                    <table border="0" cellpadding="5">

                        <tbody>


                        <tr>
                            <td>&nbsp;&nbsp;Weight(kg):<br><br></td>
                            <td>&nbsp;&nbsp;<input type="text" id="weight" name="weight" size="25"><br><br></td>
                        </tr>
                        <tr>
                            <td>&nbsp;&nbsp;Height(cm):<br><br></td>
                            <td>&nbsp;&nbsp;<input type="text" id="height" name="height" size="25"><br><br></td>
                        </tr>
                        <tr>
                            <td><br><br></td>
                            <td>&nbsp;&nbsp;<input type="button" style="float:center" class="btn btn-success btn-sm"  value="Calculate" onClick="calculateBmi()"><br><br><br></td>


                        </tr>


                        <tr>
                            <td>&nbsp;&nbsp;Your BMI:<br><br></td>
                            <td>&nbsp;&nbsp;<input type="text" id="bmi" name="bmi" size="25"><br><br></td>
                        </tr>
                        <tr>
                            <td>&nbsp;&nbsp;Means:<br><br></td>
                            <td>&nbsp;&nbsp;<input type="text" name="meaning" size="25"><br><br></td>
                        </tr>
                        <tr>
                            <td><br><br></td>
                            <td><input type="reset" style="float: center" class="btn btn-success btn-sm" value="&nbsp;&nbsp;Reset&nbsp;&nbsp;">

                                <!--input type="submit" style="float:right" id="graph" name="graph" class="btn btn-default btn-sm" value="&nbsp;&nbsp;Save&nbsp;&nbsp;"></td-->
                        </tr>

                        </tbody>
                    </table>

                </form>



            </div>
        </div>

    </div>



    <div class="col-lg-5">


<br><br>

        <div class="form-group">
            <label class="email" class="cols-sm-2 control-label" style="color: #009edf;font-size: 17px;font-style: inherit">Select BMI_Range</label>
            <br>
            <div class="cols-sm-10">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-users fa" aria-hidden="true"></i></span>
                    <select class="form-control" placeholder="Select BMI_Rnage"  name="selectBMI" id="selectBMI">
                        <option disabled>--Select_BMI_Range--</option>
                        <option value="underweight">[ BMI < 18.5 ]  Underweight</option>
                        <option value="normal">[ 18.5 < BMI < 24.9 ] Normal</option>
                        <option value="overweight">[ 25 < BMI < 29.9 ]  Overweight</option>
                        <option value="obese">[ BMI > 30 ]  Obese</option>
                    </select>
                </div>
            </div>
        </div>


        <script>

            function load1() {
                document.getElementById("selectBMI").selectedIndex = 0;
            }
        </script>

<br>
        <div class="form-group">
            <label class="email" class="cols-sm-2 control-label" style="color: #009edf;font-size: 17px;font-style: inherit">Select BMI_Range</label>
            <br>
            <div class="cols-sm-10">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-users fa" aria-hidden="true"></i></span>
                    <select class="form-control" placeholder="Select Gender"  name="selectGender" id="selectGender">
                        <option disabled>--Select_Gender--</option>
                        <option>Male</option>
                        <option>Female</option>
                    </select>
                </div>
            </div>
        </div>


        <script>

            function load2() {
                document.getElementById("selectGender").selectedIndex = 0;
            }
        </script>

<br><br>
        <button onclick="myFunction()" id="btnLogin" class="btn btn-success btn-sm" name="sportSubmit" value="">Submit</button><br><br><br>
        <script>
            function myFunction() {

                var sptinfo = {
                    selSport : document.getElementById('selectBMI').value,
                    selGender : document.getElementById('selectGender').value
                };
                $("#sportDiv").load("get-bmi-schedule.php", sptinfo);
            }
        </script>
        <div id="sportDiv">

        </div>







    </div>



</div>


<script src="js/jquery-3.1.1.js"></script>
<script src="js/bootstrap.js"></script>

</body>

</html>


