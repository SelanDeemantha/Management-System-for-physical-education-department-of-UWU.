
<!DOCTYPE html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>NOTICE</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/dashbord.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/search.css">
    <script src="js/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
</head>
<body class="home">
<body class="home" onload="load2()">
<header style="background-color: black">
    <div class="container clearfix">
        <a href="index.php"><img src="img/logo.jpg" width="175" height="120"  class="hidden-xs hidden-sm"></a>
        <ul class="nav navbar-nav navbar-right">
            <li class="dropdown" style="width: 160px; text-align: center">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button">
                    Logout<span class="caret"></span>
                </a>
                <div class="dropdown-menu" id="formLogin"  style="width: 20px">
                    <div class="row">
                        <div class="container-fluid" >
                            <form action="logout.php" method="POST">

                                <li>
                                    <button type="submit" id="btnLogin" class="btn btn-success btn-sm" style="display: block; margin: 0 auto" name="lout" value="Log Out"> Log Out </button>

                                </li>
                            </form>
                        </div>
                    </div>
                </div>
            </li>

        </ul>
    </div>
</header>
<div class="container-fluid display-table">

    <div class="row display-table-row" style="background-image: url('t.jpg');background-size: cover">
        <div class="col-md-2 col-sm-1 hidden-xs display-table-cell v-align box" id="navigation">

            <div class="navi">
                <ul>
                    <li>
                        <a href="admin.php">
                            <i class="fa fa-home" aria-hidden="true"></i>
                            <span class="hidden-xs hidden-sm">Admin Home</span></a>
                    </li>
                    
                    
                    <script>
                function myFunction2() {
                    
                    $("#notifyDiv").load("admin-notif.php");
                }
            </script>
                    <li>
                        <a href="addnotice.php">
                            <i class="fa fa-tasks" aria-hidden="true"></i>
                            <span class="hidden-xs hidden-sm">Add a notice</span></a>
                    </li>
<li>
                        <a href="addnews.php">
                            <i class="fa fa-tasks" aria-hidden="true"></i>
                            <span class="hidden-xs hidden-sm">Add a news</span></a>
                    </li>
                    <li>
                        <a href="sports.php">
                            <i class="fa fa-tasks" aria-hidden="true"></i>
                            <span class="hidden-xs hidden-sm">Sports</span></a>
                    </li>
                    <li>
                        <a href="fitnes.php" >
                            <i class="fa fa-tasks" aria-hidden="true"></i>
                            <span class="hidden-xs hidden-sm">Fitness Center</span></a>
                    </li>
                    <li>
                        <a href="groundAllo.php">
                            <i class="fa fa-tasks" aria-hidden="true"></i>
                            <span class="hidden-xs hidden-sm">Ground Allocation</span></a>
                    </li>
                    <li>
                        <a href="inventory.html">
                            <i class="fa fa-tasks" aria-hidden="true"></i>
                            <span class="hidden-xs hidden-sm">Inventory</span></a>
                    </li>

                </ul>
            </div>
        </div>
       <div  class="col-md-10 col-sm-10 display-table-cell v-align">

            <div class="form-group">




                <?php

                include_once 'config.php';

                $records=mysqli_query($con,"SELECT username FROM users");

                ?>


                <br>


                <div class="form-group" style="width: 700px">
                    <label class="email" class="cols-sm-2 control-label" style="color: #009edf;font-size: 17px;font-style: inherit">Select_User</label>
                    <br>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-users fa" aria-hidden="true"></i></span>
                            <select class="form-control" placeholder="Select User"  name="addnote" id="addnote">
                                <!--option disabled>--Select_User--</option-->


                                <?php

                                echo'<option disabled>--Select_User--</option>';

                                while($row=mysqli_fetch_array($records)){



                                  //  echo '<option value="'.username.'">'.$row['username'].'</option>';
                                    echo "<option value='" . $row['username'] ."'>" . $row['username'] ."</option>";

                                }

                                ?>


                            </select>
                        </div>
                    </div>
                </div>


                <script>

                    function load2() {
                        document.getElementById("addnote").selectedIndex = 0;
                    }
                </script>



            </div>
            <div class="form-group" style="width: 700px">
                <label class="email" class="cols-sm-2 control-label" style="color: #009edf;font-size: 17px;font-style: inherit">Notice</label>

                <input class="form-control" type="text" style="border-color: black" name="desnote" id="desnote" value="">
            </div>

            <button onclick="myFunction1()" id="sendNotice"class="btn btn-success " name="sendNotice" value="">Send</button><br><br><br>
            <script>
                function myFunction1() {

                    var noti = {
                        notic1 : document.getElementById('addnote').value,
                        notic2 : document.getElementById('desnote').value
                       
                    };
                    $("#noticeDiv").load("getnotice.php", noti);
                }
            </script> 
            <div id="noticeDiv">

            </div>

        <div class="user-dashboard"></div>
    </div>
</div>


</div>









<script src="js/jquery-3.1.1.js"></script>
<script src="js/bootstrap.js"></script>



</body>
</html>
