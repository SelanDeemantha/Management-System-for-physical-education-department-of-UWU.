<?php
$con = mysqli_connect('localhost', 'root', '', 'uwusports');

?>


<table id="mytable" class="table table-bordred table-striped" border="1">

    <thead style="background-color: sandybrown">


    <tbody>
    <?php


    if (mysqli_connect_errno()) {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }

    $bmi = $_POST["selSport"];
    $gnd = $_POST["selGender"];

    $sql = "SELECT * FROM schedule WHERE bmi_range = '" . $bmi . "' AND gender = '" . $gnd . "'";

   // $sql1 = "SELECT * FROM student WHERE gender = '" . $gnd . "' AND sport1 = '" . $spt . "' OR gender = '" . $gnd . "' AND sport2 = '" . $spt . "' OR gender = '" . $gnd . "' AND sport3 = '" . $spt . "'  ";

    $res = mysqli_query($con , $sql);

   // $res1 = mysqli_query($con , $sql1);
    ?>

    <?php
    while ($row = mysqli_fetch_assoc($res)):
        ?>
        <tr>
            <td>BMI_Range</td>
            <td> <?php echo $row['bmi_range']; ?> </td>
        </tr>
        <tr></tr>
        <tr>
            <td>Gender</td>
            <td> <?php echo $row['gender']; ?> </td>
        </tr>
        <tr></tr>
        <tr>
            <td>Schedule</td>
            <td> <?php echo $row['bmi_schedule']; ?> </td>
        </tr>


    <?php
    endwhile;
    ?>

    </tbody>

</table>

