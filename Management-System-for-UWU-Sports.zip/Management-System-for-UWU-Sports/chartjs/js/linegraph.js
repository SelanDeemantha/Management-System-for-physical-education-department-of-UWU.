$(document).ready(function(){

    $.ajax({
        url : "http://localhost:63342/GroupProject/Chartjs/load-bmi.php",
        type : "GET",
        success : function(data){
            console.log(data);

            var WEIGHT=[];
            var bmi=[];

            for(var i in data){
                WEIGHT.push("Weight " + data[i].WEIGHT);
                bmi.push(data[i].BMI);

            }

            var chartdata={

                labels: WEIGHT,
                datasets:[
                    {
                        label:"BMI",
                        fill:false,
                        lineTension:0.1,
                        backgroundColor: "rgba(59,89,152,0.75)",
                        borderColor: "rgba(59,89,152,1)",
                        pointHoverBorderColor: "rgba(59,89,152,1)",
                        data:bmi

                    }
                ]
            };

            var ctx=$("#mycanvas");
            var LineGrph= new Chart(ctx,{

                type: 'line',
                data: chartdata

            });

        },
        error : function(data){

        }
    });

});
