<?php
$con = mysqli_connect('localhost', 'root', '', 'uwusports');

?>



    <?php


    if (mysqli_connect_errno()) {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }

    $nt1 = $_POST["notic1"];
    $nt2 = $_POST["notic2"];

    
    
    $result = mysqli_query($con, "INSERT INTO notice(noticeName,noticeDescription) VALUES('" . $nt1 . "', '" . $nt2 . "')");
   $con->close();

?>

    <script>
 alert('Successfully Added The News');

    </script>