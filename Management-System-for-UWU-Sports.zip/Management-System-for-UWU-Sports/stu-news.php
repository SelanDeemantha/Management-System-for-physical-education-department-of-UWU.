<?php
session_start();
?>
<!DOCTYPE html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Stu-News</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/dashbord.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/search.css">
    <link rel="stylesheet" type="text/css" href="css/student-style.css" >
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
</head>

<body class="home">


<header style="background-color: black">
    <div class="container clearfix">
        <a href="index.php"><img src="img/logo.jpg" width="175" height="120"  class="hidden-xs hidden-sm"></a>
        <ul class="nav navbar-nav navbar-right">
            <li class="dropdown" style="width: 160px; text-align: center">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button">
                    Logout<span class="caret"></span>
                </a>
                <div class="dropdown-menu" id="formLogin"  style="width: 20px">
                    <div class="row">
                        <div class="container-fluid" >
                            <form action="logout.php" method="POST">

                                <li>
                                    <button type="submit" id="btnLogin" class="btn btn-success btn-sm" style="display: block; margin: 0 auto" name="lout" value="Log Out"> Log Out </button>

                                </li>
                            </form>
                        </div>
                    </div>
                </div>
            </li>

        </ul>
    </div>
</header>



<div class="row" style="background-image: url('s.jpg');background-size: cover">
    <div class="col-lg-3" style=" width:250px;  height:500px;  background:#1A8DA9;">

        <ul >
            <li class="backg-list"><a href="student.php">Student_Home</a></li>
            <li class="backg-list"><a href="stu-edit.php">Edit_Profile</a></li>
            <li class="backg-list"><a href="stu-notification.php">Notification</a></li>
            <li class="backg-list"><a href="stu-tweets.php">Tweet</a></li>
            <li class="backg-list"><a href="stu-bmi.php">My_BMI</a></li>
            <li class="backg-list"><a href="stu-news.php">News</a></li>
        </ul>

    </div>
    <div class="col-lg-9">



        <?php
        $con = mysqli_connect('localhost', 'root', '', 'uwusports');

        ?>

        </br>
        </br>


        <table id="mytable" class="table table-bordred table-striped" border="1">

            <thead style="background-color: lightblue">
            <tr>
                <th style="font-weight: bold;">News</th>

            </tr>
            </thead>

            <tbody>
            <?php


            if (mysqli_connect_errno()) {
                echo "Failed to connect to MySQL: " . mysqli_connect_error();
            }



            $sql = "SELECT News FROM news";



            $res = mysqli_query($con , $sql);


            ?>

            <?php
            while ($row = mysqli_fetch_assoc($res)):


                echo "<tr>";
                echo "<td>".$row['News']."</td>";
                echo "</tr>";


            endwhile;
            ?>



            </tbody>

        </table>


    </div>

</div>


<script src="js/jquery-3.1.1.js"></script>
<script src="js/bootstrap.js"></script>

</body>

</html>


