<?php

$con = mysqli_connect('localhost', 'root', '', 'uwusports');
 
//getting id of the data from url
$id = $_GET['id'];
 
//deleting the row from table
$result = mysqli_query($con, "DELETE FROM notice WHERE noticeID='".$id."'");
 
header("Location:admin.php");
?>