<?php
session_start();

$_SESSION['usr_id'];
?>
<!DOCTYPE html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Stu-BMI</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/dashbord.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/search.css">
    <link rel="stylesheet" type="text/css" href="css/student-style.css" >
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>




    <script language="JavaScript">
        <!--
        function calculateBmi() {
            var weight = document.bmiForm.weight.value
            var height = document.bmiForm.height.value
            if(weight > 0 && height > 0){
                var finalBmi = weight/(height/100*height/100)
                document.bmiForm.bmi.value = finalBmi
                if(finalBmi < 18.5){
                    document.bmiForm.meaning.value = "That you are too thin."
                }
                if(finalBmi > 18.5 && finalBmi < 25){
                    document.bmiForm.meaning.value = "That you are healthy."
                }
                if(finalBmi > 25){
                    document.bmiForm.meaning.value = "That you have overweight."
                }
            }
            else{
                alert("Please Fill in everything correctly")
            }
        }
        //-->
    </script>











</head>

<body class="home">


<header style="background-color: black">
    <div class="container clearfix">
        <a href="index.php"><img src="img/logo.jpg" width="175" height="120"  class="hidden-xs hidden-sm"></a>
        <ul class="nav navbar-nav navbar-right">
            <li class="dropdown" style="width: 160px; text-align: center">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button">
                    Logout<span class="caret"></span>
                </a>
                <div class="dropdown-menu" id="formLogin"  style="width: 20px">
                    <div class="row">
                        <div class="container-fluid" >
                            <form action="logout.php" method="POST">

                                <li>
                                    <button type="submit" id="btnLogin" class="btn btn-success btn-sm" style="display: block; margin: 0 auto" name="lout" value="Log Out"> Log Out </button>

                                </li>
                            </form>
                        </div>
                    </div>
                </div>
            </li>

        </ul>
    </div>
</header>



<div class="row" style="background-image: url('s.jpg');background-size: cover">
    <div class="col-lg-3" style=" width:250px;  height:500px;  background:#1A8DA9;">

        <ul >
            <li class="backg-list"><a href="student.php">Student_Home</a></li>
            <li class="backg-list"><a href="stu-edit.php">Edit_Profile</a></li>
            <li class="backg-list"><a href="stu-notification.php">Notification</a></li>
            <li class="backg-list"><a href="stu-tweets.php">Tweet</a></li>
            <li class="backg-list"><a href="stu-bmi.php">My_BMI</a></li>
            <li class="backg-list"><a href="stu-news.php">News</a></li>
        </ul>

    </div>
    <div class="col-lg-9">



        <div style="border: 4" sty class="row text-center">

            <h3 style="color: #009edf;float: left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Check your BMI </h3></br>
            </br></br></br>

            <div class="col-md-12 col-sm-12 icon-big" >


                <form name="bmiForm" role="form" action="bmi-graph.php" method="post">


                    <table border="0" cellpadding="5">

                        <tbody>


                        <tr>
                            <td>&nbsp;&nbsp;Weight(kg):<br><br></td>
                            <td>&nbsp;&nbsp;<input type="text" id="weight" name="weight" size="25"><br><br></td>
                        </tr>
                        <tr>
                            <td>&nbsp;&nbsp;Height(cm):<br><br></td>
                            <td>&nbsp;&nbsp;<input type="text" id="height" name="height" size="25"><br><br></td>
                        </tr>
                        <tr>
                            <td><br><br></td>
                            <td>&nbsp;&nbsp;<input type="button" style="float:center" class="btn btn-default btn-sm"  value="Calculate" onClick="calculateBmi()"><br><br><br></td>


                        </tr>


                        <tr>
                            <td>&nbsp;&nbsp;Your BMI:<br><br></td>
                            <td>&nbsp;&nbsp;<input type="text" id="bmi" name="bmi" size="25"><br><br></td>
                        </tr>
                        <tr>
                            <td>&nbsp;&nbsp;Means:<br><br></td>
                            <td>&nbsp;&nbsp;<input type="text" name="meaning" size="25"><br><br></td>
                        </tr>
                        <tr>
                            <td><br><br></td>
                            <td><input type="reset" style="float: left" class="btn btn-default btn-sm" value="&nbsp;&nbsp;Reset&nbsp;&nbsp;">

                            <input type="submit" style="float:right" id="graph" name="graph" class="btn btn-default btn-sm" value="&nbsp;&nbsp;Save&nbsp;&nbsp;"></td>
                        </tr>

                        </tbody>
                    </table>

                </form>



            </div>
        </div>







    </div>

</div>


<script src="js/jquery-3.1.1.js"></script>
<script src="js/bootstrap.js"></script>

</body>

</html>


