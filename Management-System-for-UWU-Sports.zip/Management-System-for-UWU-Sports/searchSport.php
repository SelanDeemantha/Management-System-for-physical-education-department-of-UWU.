<?php
//including the database connection file
include_once("config.php");

$selectSport = $_POST['selectSport'];
$selectGender = $_POST['selectGender'];

$result = mysqli_query($mysqli, "SELECT * FROM sportlist WHERE sportName = '$selectSport' AND gender = '$selectGender'"); // using mysqli_query instead



?>