<?php
session_start();
$_SESSION['usr_id'];
?>
<!DOCTYPE html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Fitness Center</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/dashbord.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/search.css">
    <link rel="stylesheet" type="text/css" href="css/student-style.css" >
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
</head>

<body class="home">


<header style="background-color: black">
    <div class="container clearfix">
        <img src="img/logo.jpg" width="175" height="120"  class="hidden-xs hidden-sm">
        <ul class="nav navbar-nav navbar-right">
            <li class="dropdown" style="width: 160px; text-align: center">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button">
                    Logout<span class="caret"></span>
                </a>
                <div class="dropdown-menu" id="formLogin"  style="width: 20px">
                    <div class="row">
                        <div class="container-fluid" >
                            <form action="logout.php" method="POST">

                                <li>
                                    <button type="submit" id="btnLogin" class="btn btn-success btn-sm" style="display: block; margin: 0 auto" name="lout" value="Log Out"> Log Out </button>

                                </li>
                            </form>
                        </div>
                    </div>
                </div>
            </li>

        </ul>
    </div>
</header>



<div class="row">
    <div class="col-lg-3" style=" width:250px;  height:500px;  background:#1A8DA9;">

        <ul >
            <!--<li class="backg-list"><a href="index.php">Home</a></li>-->
            <li class="backg-list"><a href="fitnes.php">Fitnes_Home</a></li>
            <li class="backg-list"><a href="#">Availability</a></li>
            <li class="backg-list"><a href="#">Special_Notices</a></li>
            <li class="backg-list"><a href="bmi-graph.php">Calculate_BMI</a></li>
            <li class="backg-list"><a href="fit-que.php">Ask_Question</a></li>
            <li class="backg-list"><a href="fit-que.php">Show_Answer</a></li>


        </ul>

    </div>
    <div class="col-lg-9">

        <?php

        include_once 'config.php';

        $records=mysqli_query($con,"SELECT qid,question,ans,image FROM answer");

        ?>

        <br>
        <br>


        <table class="table">
            <thead style="background-color: lightblue">

            <tr>
                <th>que_id</th>
                <th>question</th>
                <th>answer</th>
                <th>image</th>
                <!--<th>answer</th>-->



            </tr>
            </thead>


            <tbody>
            <?php
            while($row=mysqli_fetch_array($records)){



                echo "<tr><form method=post>";
                echo"<td><input style='height: 40px;width: 50px' type=text name=queid value='".$row['qid']."'></td>";
                echo"<td><input style='height: 40px;width: 300px' type=text name=question value='".$row['question']."'></td>";
                echo"<td><input style='height: 40px;width: 300px' type=text name=answer value='".$row['ans']."'></td>";
                echo"<td><img src='data:image/jpeg;base64,".base64_encode($row['image'])."' style='width:220px; height:150px'></td>";
                echo"</form></tr>";








            }


            ?>







            </tbody>

        </table>
















    </div>

</div>


<script src="js/jquery-3.1.1.js"></script>
<script src="js/bootstrap.js"></script>

</body>

</html>


