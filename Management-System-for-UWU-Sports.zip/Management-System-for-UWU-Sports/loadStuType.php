

<div class="form-group">
                    <label class="email" class="cols-sm-2 control-label"><br>Academic Year</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-home" aria-hidden="true"></i></span>
                            <input type="text" class="form-control" name="acYear" id="acYear"  placeholder="Academic Year"/>
                        </div>
                    </div>
                </div>

  
  <div class="form-group">
                    <label class="email" class="cols-sm-2 control-label">Date of Birth</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-home" aria-hidden="true"></i></span>
                            <input type="date" class="form-control" name="DOB" id="DOB"  placeholder=""/>
                        </div>
                    </div>
                </div>

<div class="form-group">
                    <label class="email" class="cols-sm-2 control-label">Select Sport 1</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-home" aria-hidden="true"></i></span>
                            <select class="form-control"  placeholder="Sport 1"  name="selectSport1" id="selectSport1">
                    <option></option>
                    <option>Badminton</option>
                    <option>Baseball</option>
                    <option>Basketball</option>
                    <option>Chess</option>
                    <option>Cricket</option>
                    <option>Elle</option>
                    <option>Football</option>
                    <option>Hockey</option>
                    <option>Karate</option>
                    <option>Netball</option>
                    <option>Rugby</option>
                    <option>Swimming</option>
                    <option>Table Tennis</option>
                    <option>Taekwondo</option>
                    <option>Tennis</option>
                    <option>Track and Field</option>
                    <option>Volleyball</option>
                    <option>Weight Lifting</option>
                </select>
                        </div>
                    </div>
                </div>

<div class="form-group">
                    <label class="email" class="cols-sm-2 control-label">Select Sport 2</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-home" aria-hidden="true"></i></span>
                            <select class="form-control"  placeholder="Sport 2"  name="selectSport2" id="selectSport2">
                    <option></option>
                    <option>Badminton</option>
                    <option>Baseball</option>
                    <option>Basketball</option>
                    <option>Chess</option>
                    <option>Cricket</option>
                    <option>Elle</option>
                    <option>Football</option>
                    <option>Hockey</option>
                    <option>Karate</option>
                    <option>Netball</option>
                    <option>Rugby</option>
                    <option>Swimming</option>
                    <option>Table Tennis</option>
                    <option>Taekwondo</option>
                    <option>Tennis</option>
                    <option>Track and Field</option>
                    <option>Volleyball</option>
                    <option>Weight Lifting</option>
                </select>
                        </div>
                    </div>
                </div>

<div class="form-group">
                    <label class="email" class="cols-sm-2 control-label">Select Sport 3</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-home" aria-hidden="true"></i></span>
                            <select class="form-control"  placeholder="Sport 3"  name="selectSport3" id="selectSport3">
                    <option></option>
                    <option>Badminton</option>
                    <option>Baseball</option>
                    <option>Basketball</option>
                    <option>Chess</option>
                    <option>Cricket</option>
                    <option>Elle</option>
                    <option>Football</option>
                    <option>Hockey</option>
                    <option>Karate</option>
                    <option>Netball</option>
                    <option>Rugby</option>
                    <option>Swimming</option>
                    <option>Table Tennis</option>
                    <option>Taekwondo</option>
                    <option>Tennis</option>
                    <option>Track and Field</option>
                    <option>Volleyball</option>
                    <option>Weight Lifting</option>
                </select>
                        </div>
                    </div>
                </div>

<div class="form-group">
                    <label class="email" class="cols-sm-2 control-label">Achivements</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-home" aria-hidden="true"></i></span>
                            <input type="text" class="form-control" name="ach" id="ach"  placeholder="Achivements"/>
                        </div>
                    </div>
                </div>

<div class="form-group">
                    <label class="email" class="cols-sm-2 control-label">Start Date</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-home" aria-hidden="true"></i></span>
                            <input type="date" class="form-control" name="SD" id="SD"  placeholder=""/>
                        </div>
                    </div>
                </div>
<!--
<div class="form-group">
                    <label class="email" class="cols-sm-2 control-label">End Date</label>
                    <div class="cols-sm-10">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-home" aria-hidden="true"></i></span>
                            <input type="date" class="form-control" name="ED" id="ED"  placeholder=""/>
                        </div>
                    </div>
                </div>
-->
