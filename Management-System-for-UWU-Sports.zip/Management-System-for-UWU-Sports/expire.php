<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Home</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/dashbord.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/search.css">

   
</head>
<body class="home">
<header style="background-color: black">
    <div class="container clearfix">
        <a href="index.php"> <img src="img/logo.jpg" width="175" height="120"  class="hidden-xs hidden-sm"></a>
</header>

<div id="myCarousel" class="carousel slide">
    <!-- Indicators -->

    <div class="carousel-inner">
        <h1>Your account has been expired. You can not login</h1>
    </div>
    <div><a href="index.php">Go Back To Home Page</a></div>

    

    </div>


<script src="js/jquery-3.1.1.js"></script>
<script src="js/bootstrap.js"></script>


</body>
</html>