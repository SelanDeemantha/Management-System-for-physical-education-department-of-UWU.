<?php
session_start();
?>
<!DOCTYPE html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Stu-Tweets</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/dashbord.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/search.css">
    <link rel="stylesheet" type="text/css" href="css/student-style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
</head>

<body class="home" onload="load()">


<header style="background-color: black">
    <div class="container clearfix">
    
        <a href="index.php"><img src="img/logo.jpg" width="175" height="120"  class="hidden-xs hidden-sm"></a>
        
        <ul class="nav navbar-nav navbar-right">
            <li class="dropdown" style="width: 160px; text-align: center">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button">
                    Logout<span class="caret"></span>
                </a>

                <div class="dropdown-menu" id="formLogin" style="width: 20px">
                    <div class="row">
                        <div class="container-fluid">
                            <form action="logout.php" method="POST">

                                <li>
                                    <button type="submit" id="btnLogin" class="btn btn-success btn-sm"
                                            style="display: block; margin: 0 auto" name="lout" value="Log Out"> Log Out
                                    </button>

                                </li>
                            </form>
                        </div>
                    </div>
                </div>
            </li>

        </ul>
    </div>
</header>


<div class="row" style="background-image: url('s.jpg');background-size: cover">
    <div class="col-lg-3" style=" width:250px;  height:500px;  background:#1A8DA9;">

        <ul>
            <li class="backg-list"><a href="student.php">Student_Home</a></li>
            <li class="backg-list"><a href="stu-edit.php">Edit_Profile</a></li>
            <li class="backg-list"><a href="stu-notification.php">Notification</a></li>
            <li class="backg-list"><a href="stu-tweets.php">Tweet</a></li>
            <li class="backg-list"><a href="stu-bmi.php">My_BMI</a></li>
            <li class="backg-list"><a href="stu-news.php">News</a></li>
        </ul>

    </div>

    <div class="col-lg-9">

        <div class="form-group">
            <label>Select Sport</label>
            <select class="form-control" style="border-color: black" name="selectSport" id="selectSport"
                    onchange="selecting()">
                <option disabled>--Select--</option>
                <option>Basketball</option>
                <option>Taekwondo</option>
                <option>Badminton</option>
                <option>Netball</option>
                <option>Cricket</option>
                <option>Elle</option>
                <option>Football</option>
                <option>Hockey</option>
                <option>Chess</option>
                <option>Volleyball</option>
                <option>Rugby</option>
                <option>Swimming</option>
                <option>Baseball</option>
                <option>Tennis</option>
                <option>Karate</option>
                <option>Table Tennis</option>
                <option>Track and Field</option>
                <option>Weight Lifting</option>
            </select>
        </div>

    </div>


    <br><br><br>


    <script>
        function selecting() {


            var x = document.getElementById("selectSport").selectedIndex;
            if (x == 1) {
                window.open("https://twitter.com/UWUBASKETBALL", "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=300,left=250,width=1090,height=400");
            } else if (x == 2) {
                window.open("https://twitter.com/UWUTaekwondo", "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=300,left=250,width=1090,height=400");
            }
            else if (x == 3) {
                window.open("https://twitter.com/uwubadminton", "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=300,left=250,width=1090,height=400");
            }
            else if (x == 4) {
                window.open("https://twitter.com/netballteam", "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=300,left=250,width=1090,height=400");
            }
            else if (x == 5) {
                window.open("https://twitter.com/uwucricketteam", "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=300,left=250,width=1090,height=400");
            }
            else if (x == 6) {
                window.open("https://twitter.com/uwuelle2017", "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=300,left=250,width=1090,height=400");
            }
            else if (x == 7) {
                window.open("https://twitter.com/uwusoccer", "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=300,left=250,width=1090,height=400");
            } else if (x == 8) {
                window.open("https://twitter.com/UWUHockey", "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=300,left=250,width=1090,height=400");
            }
            else if (x == 9) {
                window.open("https://twitter.com/uwuchess", "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=300,left=250,width=1090,height=400");
            }
            else if (x == 10) {
                window.open("https://twitter.com/UwuVollyball", "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=300,left=250,width=1090,height=400");
            }
            else if (x == 11) {
                window.open("https://twitter.com/UVARUGBY2017", "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=300,left=250,width=1090,height=400");
            } else if (x == 12) {
                window.open("https://twitter.com/uwuswimming", "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=300,left=250,width=1090,height=400");
            } else if (x == 13) {
                window.open("https://twitter.com/uwuBaseball", "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=300,left=250,width=1090,height=400");
            } else if (x == 14) {
                window.open("https://twitter.com/uwuTennis", "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=300,left=250,width=1090,height=400");
            } else if (x == 15) {
                window.open("https://twitter.com/uwuKarate", "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=300,left=250,width=1090,height=400");
            } else if (x == 16) {
                window.open("https://twitter.com/uwuTabletennis", "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=300,left=250,width=1090,height=400");
            } else if (x == 17) {
                window.open("https://twitter.com/uwuTracking", "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=300,left=250,width=1090,height=400");
            }
            else {
                window.open("https://twitter.com/uwuweightliftin", "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=300,left=250,width=1090,height=400");
            }
        }
        function load() {
            document.getElementById("selectSport").selectedIndex = 0;
        }
    </script>


</div>

</div>


<script src="js/jquery-3.1.1.js"></script>
<script src="js/bootstrap.js"></script>

</body>

</html>


