<?php
session_start();

/*if(isset($_SESSION['usr_id'])!="") {
    header("Location: admin.php");
}*/

include_once 'config.php';

//check if form is submitted
if (isset($_POST['loginform'])) {

    $username = mysqli_real_escape_string($con, $_POST['username']);
    $password = mysqli_real_escape_string($con, $_POST['password']);
    $type = mysqli_real_escape_string($con, $_POST['selectType']);

    $result = mysqli_query($con, "SELECT * FROM users WHERE username = '" . $username . "' and password = '" . md5($password) . "' and type = '".$type."'");

    if ($row = mysqli_fetch_array($result)) {
        $_SESSION['usr_id'] = $row['id'];
        $_SESSION['usr_name'] = $row['username'];
        $_SESSION['usr_type'] = $row['type'];
        $_SESSION['usr_regDae'] = $row['regDate'];
        $_SESSION['ini_t'] = $row['initials'];

        if($_SESSION['usr_type']=="Admin"){

        header("Location: admin.php");
        
        }
if($_SESSION['usr_type']=="Student"){
    
    include_once 'config.php';

            $records=mysqli_query($con,"SELECT * FROM student");

            if($row=mysqli_fetch_array($records)) {

                $_SESSION['autoid'] = $row['auto_id'];

            }

            header("Location: student.php");
            
            }
            
        if($_SESSION['usr_type']=="Coach"){

        header("Location: coach.php");
        
        }
        if($_SESSION['usr_type']=="Staff"){

        header("Location: staff.php");
        
        }

         
}else {
            $errormsg = "Incorrect Username or Password!!!";
        }}

?>
<!DOCTYPE html>

<head>
	<meta charset="utf-8">
	<title>Login</title>
        
	<link rel="stylesheet" href="css/style1.css" type="text/css">
        
       

</head>
<body onload="load()">
    <div  id="header1" style="width: 960px;margin: 0 auto;background-color : black;height: 133px;">
		<div id="logo">
                    <a href="index.php"> <img src="img/logo.jpg" alt="LOGO" style="width: 200px ;height: 115px"> </a>
		</div>
		<ul id="navigation">
			<li class="active">
                            <a href="index.php">Home</a>
			</li>
			
		</ul>
	</div>
	<div id="body">
		<div id="contents">
			<div id="journey">
				<img src="img/bikers-journey.jpg" alt="journey Img">
				<h1>Login</h1>
				 <form role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="loginform">

                                     <br>
                <div class="form-group">
                    <label >Username</label>
                    <div >
                        <div >
                           
                            <input type="text" style="padding: 12px 20px;margin: 8px 0;display: inline-block;border: 1px solid #ccc;border-radius: 4px;box-sizing: border-box;width: 500px"  name="username" id="username"  placeholder="Enter your Username"/>
                        </div>
                    </div>
                </div>
          <div ><br>
                    <label >Select Type</label>
                    <div class="cols-sm-10">
                        <div >


                            <select style="padding: 12px 20px;margin: 8px 0;display: inline-block;border: 1px solid #ccc;border-radius: 4px;box-sizing: border-box;width: 500px;" placeholder="Select Type"  name="selectType" id="selectType">
                                <option disabled>--Select--</option>
                                <option>Student</option>
                                <option>Coach</option>
                                <option>Staff</option>
                                <option>Admin</option>


                            </select>

<script>

                    function load() {
                        document.getElementById("selectType").selectedIndex = 0;
                    }
                </script>
                        </div>

                    </div>
                </div>









<br>
                <div class="form-group">
                    <label >Password</label>
                    <div >
                        <div >
                            <input type="password" style="padding: 12px 20px;margin: 8px 0;display: inline-block;border: 1px solid #ccc;border-radius: 4px;box-sizing: border-box;width: 500px;" name="password" id="password"  placeholder="Enter your Password" required class="form-control"/>
                        </div>
                        <span class="text-danger" style="color: black;font-family: Arial;"><?php if (isset($password_error)) echo $password_error; ?></span>
                    </div>
                </div>

<br>
                <div class="form-group ">

                    <input type="submit" style="width: 100px;background-color: #4CAF50;color: white; padding: 14px 20px;margin: 8px 0;border: none;border-radius: 4px;cursor: pointer;"  name="loginform" value="Login" class="btn btn-primary" placeholder="Login" />
                </div>

<br>
                <div class="form-group">
                    <label class="confirm" class="cols-sm-2 control-label">New User?&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="register.php" style="text-decoration: none;">  Register Here</a></label>
                    <div class="cols-sm-10">
                    </div>
                </div>



            </form>

            <span class="text-danger"><?php if (isset($errormsg)) { echo $errormsg; } ?></span>
			</div>
		</div>
		
	</div>
	<div id="footer1">
		<ul id="connect">
			<li>
				<a href="http://facebook.com" target="_blank" class="facebook" title="Facebook"></a>
			</li>
			<li>
				<a href="http://twitter.com" target="_blank" class="twitter" title="Twitter"></a>
			</li>
			
			<li>
				<a href="http://googleplus.com" target="_blank" class="googleplus" title="Google+"></a>
			</li>
		</ul>
		<div id="footnote">
			<ul>
				<li>
                                    <a href="index.php">Home</a>
				</li>
				<li>
					<a href="about.html">About</a>
				</li>
			</ul>
			<span>&copy; Copyright &copy; 2017. UWU SPORTS. All rights reserved.</span>
		</div>
	</div>
</body>
</html>