
<!DOCTYPE html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>SPORTS</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/dashbord.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/search.css">
    <script src="js/jquery.min.js"></script>
</head>
<body class="home">
<header style="background-color: black">
    <div class="container clearfix">
        <img src="img/logo.jpg" width="175" height="120"  class="hidden-xs hidden-sm">
        <ul class="nav navbar-nav navbar-right">
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button">
                    Logout<span class="caret"></span>
                </a>
                <div class="dropdown-menu" id="formLogin"  style="width: 20px">
                    <div class="row">
                        <div class="container-fluid" >
                            <form action="logout.php" method="POST">

                                <li>
                                    <button type="submit" id="btnLogin" class="btn btn-success btn-sm" style="display: block; margin: 0 auto" name="lout" value="Log Out"> Log Out </button>

                                </li>
                            </form>
                        </div>
                    </div>
                </div>
            </li>

        </ul>
    </div>
</header>
<div class="container-fluid display-table">

    <div class="row display-table-row">
        <div class="col-md-2 col-sm-1 hidden-xs display-table-cell v-align box" id="navigation">

            <div class="navi">
                <ul>
                    <li>
                        <a href="admin.php">
                            <i class="fa fa-home" aria-hidden="true"></i>
                            <span class="hidden-xs hidden-sm">Admin Home</span></a>
                    </li>
                    <li>
                        <a href="inventory.html">
                            <i class="fa fa-tasks" aria-hidden="true"></i>
                            <span class="hidden-xs hidden-sm">Inventory</span></a>
                    </li>
                    <li>
                        <a href="#" data-toggle="modal" data-target="#notify">
                            <i class="fa fa-tasks" aria-hidden="true"></i>
                            <span class="hidden-xs hidden-sm">Notifications</span></a>
                    </li>
                    <li>
                        <a href="addnotice.php" >
                            <i class="fa fa-tasks" aria-hidden="true"></i>
                            <span class="hidden-xs hidden-sm">Add a notice</span></a>
                    </li>

                    <li>
                        <a href="sports.php">
                            <i class="fa fa-tasks" aria-hidden="true"></i>
                            <span class="hidden-xs hidden-sm">Sports</span></a>
                    </li>
                    <li>
                        <a href="fitness.php" >
                            <i class="fa fa-tasks" aria-hidden="true"></i>
                            <span class="hidden-xs hidden-sm">Fitness Center</span></a>
                    </li>
                    <li>
                        <a href="#" data-toggle="modal" data-target="#ground">
                            <i class="fa fa-tasks" aria-hidden="true"></i>
                            <span class="hidden-xs hidden-sm">Ground Allocation</span></a>
                    </li>

                </ul>
            </div>
        </div>
       <?php

        include_once 'config.php';

        $records=mysqli_query($con,"SELECT * FROM sportlist");

        ?>

        <br>
        <br>


        <table>
            <thead style="background-color: lightblue">

            <tr>

                <th>Name</th>
                <th>Gender</th>
                <th>Instructor</th>
                <th>Coach</th>
                <th>Captain</th>
                <th>Vice Captain</th>
                
            </tr>
                 </thead>

                
            <tbody>
            <?php
            while($row=mysqli_fetch_array($records)){


                //   $_SESSION['student_id'] = $row['studentid'];


                echo "<tr><form action=editSportlist.php method=post>";
                echo"<td><input type=text name=sprtName value='".$row['sportName']."' readonly=readonly></td>";
                echo"<td><input type=text name=gender value='".$row['gender']."' readonly=readonly></td>";
                echo"<td><input type=text name=incharge value='".$row['incharge']."'></td>";
                echo"<td><input type=text name=coach value='".$row['coach']."'></td>";
                echo"<td><input type=text name=captain value='".$row['captain']."'></td>";
                echo"<td><input type=text name=viceCaptain value='".$row['viceCaptain']."'></td>";
                
                echo"<input type=hidden name=id value='".$row['sportID']."'>";
                echo"<td><input type=submit></td>";
                echo"</form></tr>";

            }


            ?>

 </tbody>

 </table>
</div>


</div>



<!-- Modal -->











<div id="notice" class="modal fade" role="dialog">
    <form action="dashbord.jsp" method="post">
       





<div id="ground" class="modal fade" role="dialog">
    <form action="" method="post">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header login-header">
                    <button type="button" class="close" data-dismiss="modal">×</button>
                    <h4 class="modal-title">Ground Allocation</h4>
                </div>
                <div class="modal-body">

                    <div class="modal-footer">
                        <button type="button" class="cancel" data-dismiss="modal">Close</button>
                        <button type="reset" class="add-project" data-dismiss="modal">Reset</button>
                        <button type="submit" id="btnLogin" class="btn btn-success btn-sm" name="action" value="submitd">Submit</button>
                    </div>
                </div>

            </div>
    </form>
</div>


<script src="js/jquery-3.1.1.js"></script>
<script src="js/bootstrap.js"></script>


</body>
</html>


<?php

        include_once 'config.php';

        $records=mysqli_query($con,"SELECT * FROM sportlist");

        ?>

        <br>
        <br>


        <table>
            <thead style="background-color: lightblue">

            <tr>

                <th>Name</th>
                <th>Gender</th>
                <th>Instructor</th>
                <th>Coach</th>
                <th>Captain</th>
                <th>Vice Captain</th>
                
            </tr>
                 </thead>

                
            <tbody>
            <?php
            while($row=mysqli_fetch_array($records)){


                //   $_SESSION['student_id'] = $row['studentid'];


                echo "<tr><form action=editSportlist.php method=post>";
                echo"<td><input type=text name=sprtName value='".$row['sportName']."' readonly=readonly></td>";
                echo"<td><input type=text name=gender value='".$row['gender']."' readonly=readonly></td>";
                echo"<td><input type=text name=incharge value='".$row['incharge']."'></td>";
                echo"<td><input type=text name=coach value='".$row['coach']."'></td>";
                echo"<td><input type=text name=captain value='".$row['captain']."'></td>";
                echo"<td><input type=text name=viceCaptain value='".$row['viceCaptain']."'></td>";
                
                echo"<input type=hidden name=id value='".$row['sportID']."'>";
                echo"<td><input type=submit></td>";
                echo"</form></tr>";

            }


            ?>

 </tbody>

 </table>
