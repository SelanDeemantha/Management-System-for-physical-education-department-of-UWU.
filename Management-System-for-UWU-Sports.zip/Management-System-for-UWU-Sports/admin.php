    <?php
session_start();

include_once 'config.php';
    



?>

<!DOCTYPE html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>ADMIN</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/dashbord.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/search.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
</head>
<body class="home">
<header style="background-color: black">
    <div class="container clearfix">
        <a href="index.php"> <img src="img/logo.jpg" width="175" height="120"  class="hidden-xs hidden-sm"></a>
        <ul class="nav navbar-nav navbar-right">
            <li class="dropdown" style="width: 160px; text-align: center">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button">
                    Logout<span class="caret"></span>
                </a>
                <div class="dropdown-menu" id="formLogin"  style="width: 20px">
                    <div class="row">
                        <div class="container-fluid" >
                            <form action="logout.php" method="POST">

                                <li>
                                    <button type="submit" id="btnLogin" class="btn btn-success btn-sm" style="display: block; margin: 0 auto" name="lout" value="Log Out"> Log Out </button>

                                </li>
                            </form>
                        </div>
                    </div>
                </div>
            </li>

        </ul>
    </div>
</header>
<div class="container-fluid display-table">

    <div class="row display-table-row" style="background-image: url('t.jpg');background-size: cover">
        <div class="col-md-2 col-sm-1 hidden-xs display-table-cell v-align box" id="navigation">

            <div class="navi">
                <ul>
                    <li>
                        <a href="admin.php">
                            <i class="fa fa-home" aria-hidden="true"></i>
                            <span class="hidden-xs hidden-sm">Admin Home</span></a>
                    </li>
                    
                    
                    <script>
                function myFunction2() {
                    
                    $("#notifyDiv").load("admin-notif.php");
                }
            </script>
                    <li>
                        <a href="addnotice.php">
                            <i class="fa fa-tasks" aria-hidden="true"></i>
                            <span class="hidden-xs hidden-sm">Add a notice</span></a>
                    </li>
<li>
                        <a href="addnews.php">
                            <i class="fa fa-tasks" aria-hidden="true"></i>
                            <span class="hidden-xs hidden-sm">Add a news</span></a>
                    </li>
                    <li>
                        <a href="sports.php">
                            <i class="fa fa-tasks" aria-hidden="true"></i>
                            <span class="hidden-xs hidden-sm">Sports</span></a>
                    </li>
                    <li>
                        <a href="fitnes.php" >
                            <i class="fa fa-tasks" aria-hidden="true"></i>
                            <span class="hidden-xs hidden-sm">Fitness Center</span></a>
                    </li>
                    <li>
                        <a href="groundAllo.php">
                            <i class="fa fa-tasks" aria-hidden="true"></i>
                            <span class="hidden-xs hidden-sm">Ground Allocation</span></a>
                    </li>
                    <li>
                        <a href="inventory.html">
                            <i class="fa fa-tasks" aria-hidden="true"></i>
                            <span class="hidden-xs hidden-sm">Inventory</span></a>
                    </li>

                </ul>
            </div>
        </div>
        
        <div id="notifyDiv"></div>

        <div class="user-dashboard" ></div>
        
            <?php echo "<h3>&nbsp;&nbsp;&nbsp;&nbsp;Welcome       ". $_SESSION['usr_name']."</h3><br>";?>
        </div>
    </div>


</div>


<script src="js/jquery-3.1.1.js"></script>
<script src="js/bootstrap.js"></script>
</body>
</html>
