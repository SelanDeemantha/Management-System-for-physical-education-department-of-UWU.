<?php
    session_start();
    $_SESSION['usr_id'];
    
    
    $userRegDate = $_SESSION['usr_regDae'];
    $membershipEnds = date("Y-m-d",  strtotime(date("Y-m-d",  strtotime($userRegDate))."+ 1000 day"));
    
     if(date("Y-m-d") > $membershipEnds){ 
          header("Location:expire.php");
} else {  
       
 }
 
 include_once 'config.php';
?>
<!DOCTYPE html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Student</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/dashbord.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/search.css">
    <link rel="stylesheet" type="text/css" href="css/student-style.css" >
   <script src="js/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
</head>

<body class="home">


<header style="background-color: black">
    <div class="container clearfix">
        <a href="index.php"><img src="img/logo.jpg" width="175" height="120"  class="hidden-xs hidden-sm"></a>
        <ul class="nav navbar-nav navbar-right">
            <li class="dropdown" style="width: 160px; text-align: center">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button">
                    Logout<span class="caret"></span>
                </a>
                <div class="dropdown-menu" id="formLogin"  style="width: 20px">
                    <div class="row">
                        <div class="container-fluid" >
                            <form action="logout.php" method="POST">

                                <li>
                                    <button type="submit" id="btnLogin" class="btn btn-success btn-sm" style="display: block; margin: 0 auto" name="lout" value="Log Out"> Log Out </button>

                                </li>
                            </form>
                        </div>
                    </div>
                </div>
            </li>

        </ul>
    </div>
</header>



<div class="row" style="background-image: url('s.jpg');background-size: cover">
    <div class="col-lg-3" style=" width:250px;  height:500px;  background:#1A8DA9;">

      <ul >
        <li class="backg-list"><a href="fitnes.php">Fitnes_Center</a></li>
        <li class="backg-list"><a href="stu-edit.php">Edit_Profile</a></li>
        <li class="backg-list"><a href="stu-notification.php">Notification</a></li>
          <li class="backg-list"><a href="stu-bmi.php">My_BMI</a></li>
          <li class="backg-list"><a href="stu-tweets.php">Tweet</a></li>
        <li class="backg-list"><a href="stu-news.php">News</a></li>
    </ul>

    </div>
    <div class="col-lg-9">
<p style="font-size: medium;font-weight: bold; color:#2b669a">
        <?php

        echo "WELCOME ,&nbsp;&nbsp;&nbsp;&nbsp; ". $_SESSION['usr_name'];

        ?><p>

    </div>

</div>


<script src="js/jquery-3.1.1.js"></script>
<script src="js/bootstrap.js"></script>

</body>

</html>


