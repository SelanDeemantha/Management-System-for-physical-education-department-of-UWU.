<?php
session_start();

//$_SESSION['stu_id'];
$_SESSION['usr_id'];
//$_SESSION['last_id'];
$_SESSION['autoid'];
$_SESSION['usr_name'];


//echo $_SESSION['last_id'];


?>
<!DOCTYPE html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Stu-Edit</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/dashbord.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/search.css">
    <link rel="stylesheet" type="text/css" href="css/student-style.css" >
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
</head>

<body class="home">


<header style="background-color: black">
    <div class="container clearfix">
        <img src="img/logo.jpg" width="175" height="120"  class="hidden-xs hidden-sm">
        <ul class="nav navbar-nav navbar-right">
            <li class="dropdown" style="width: 160px; text-align: center">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button">
                    Logout<span class="caret"></span>
                </a>
                <div class="dropdown-menu" id="formLogin"  style="width: 20px">
                    <div class="row">
                        <div class="container-fluid" >
                            <form action="logout.php" method="POST">

                                <li>
                                    <button type="submit" id="btnLogin" class="btn btn-success btn-sm" style="display: block; margin: 0 auto" name="lout" value="Log Out"> Log Out </button>

                                </li>
                            </form>
                        </div>
                    </div>
                </div>
            </li>

        </ul>
    </div>
</header>



<div class="row" style="background-image: url('s.jpg');background-size: cover">
    <div class="col-lg-3" style=" width:250px;  height:500px;  background:#1A8DA9;">

        <ul >
            <li class="backg-list"><a href="student.php">Stu_Home</a></li>
            <li class="backg-list"><a href="stu-edit.php">Edit_Profile</a></li>
            <li class="backg-list"><a href="stu-notification.php">Notification</a></li>
            <li class="backg-list"><a href="stu-bmi.php">My_BMI</a></li>
            <li class="backg-list"><a href="stu-tweets.php">Tweet</a></li>
            <li class="backg-list"><a href="stu-news.php">News</a></li>
        </ul>

    </div>
    <div class="col-lg-9">



        <?php

        include_once 'config.php';

        $records=mysqli_query($con,"SELECT * FROM student where auto_id='".$_SESSION['usr_id']."'");

        ?>

        <br>
        <br>

        <p style="font-size: medium;font-weight: bold; color:#2b669a">
        <?php

        echo "user, ". $_SESSION['usr_name'];

        ?><p>



        <table>
            <thead style="background-color: lightblue">

            <tr>

                <th>Name</th>
                
                <th>address</th>
                <th>number</th>
                <th>Year</th>
                <th>sport1</th>
                <th>sport2</th>
                
                <th>achivemnets</th>
                

            </tr>
                 </thead>


            <tbody>
            <?php
            while($row=mysqli_fetch_array($records)){

               // $_SESSION['student_id'] = $row['studentid'];


                echo "<tr><form action=stu-update.php method=post>";
                echo"<td><input type=text name=name value='".$row['studentname']."'></td>";
                //echo"<td><input type=text name=regno value='".$row['regno']."'></td>";
                //echo"<td><input type=text name=gender value='".$row['gender']."'></td>";
                //echo"<td><input type=date name=dob value='".$row['dob']."'></td>";

                echo"<td><input type=text name=address value='".$row['address']."'></td>";
                echo"<td><input type=number name=number value='".$row['number']."'></td>";

                echo"<td><input type=number name=acyr value='".$row['acyr']."'></td>";
                echo"<td><input type=text name=sport1 value='".$row['sport1']."'></td>";
                echo"<td><input type=text name=sport2 value='".$row['sport2']."'></td>";
               // echo"<td><input type=text name=sport3 value='".$row['sport3']."'></td>";
                echo"<td><input type=text name=achivements value='".$row['achivements']."'></td>";
                //echo"<td><input type=date name=startdate value='".$row['startdate']."'></td>";
                echo"<input type=hidden name=id value='".$row['studentid']."'>";
                echo"<td><input type=submit></td>";
                echo"</form></tr>";

            }


            ?>

 </tbody>

 </table>




<script src="js/jquery-3.1.1.js"></script>
<script src="js/bootstrap.js"></script>

    </div>

</div>
