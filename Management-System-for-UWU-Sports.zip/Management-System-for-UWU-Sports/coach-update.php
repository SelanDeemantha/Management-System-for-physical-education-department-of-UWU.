<?php
session_start();
$_SESSION['usr_id'];
$_SESSION['usr_name'];


$queid= $_POST['queid'];
$quetext= $_POST['quetext'];





?>
<!DOCTYPE html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Fitness Center</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/dashbord.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/search.css">
    <link rel="stylesheet" type="text/css" href="css/student-style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
</head>

<body class="home">


<header style="background-color: black">
    <div class="container clearfix">
        <a href="index.php"><img src="img/logo.jpg" width="175" height="120"  class="hidden-xs hidden-sm"></a>
        <ul class="nav navbar-nav navbar-right">
            <li class="dropdown" style="width: 160px; text-align: center">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button">
                    Logout<span class="caret"></span>
                </a>
                <div class="dropdown-menu" id="formLogin"  style="width: 20px">
                    <div class="row">
                        <div class="container-fluid" >
                            <form action="logout.php" method="POST">

                                <li>
                                    <button type="submit" id="btnLogin" class="btn btn-success btn-sm" style="display: block; margin: 0 auto" name="lout" value="Log Out"> Log Out </button>

                                </li>
                            </form>
                        </div>
                    </div>
                </div>
            </li>

        </ul>
    </div>
</header>



<div class="row" style="background-image: url('s.jpg');background-size: cover">
    <div class="col-lg-3" style=" width:250px;  height:500px;  background:#1A8DA9;">

        <ul >
            <li class="backg-list"><a href="coach.php">Coach_Home</a></li>
            <li class="backg-list"><a href="#">Availability</a></li>
            <li class="backg-list"><a href="#">Special_Notices</a></li>
            <li class="backg-list"><a href="#">Calculate_BMI</a></li>
            <li class="backg-list"><a href="fit-que.php">Ask_Question</a></li>
            <li class="backg-list"><a href="coach-ans.php">Give_Answer</a></li>

        </ul>

    </div>

    <div class="col-lg-9">



        <br<br><br><br>

        <p style="font-size: medium;font-weight: bold; color:#2b669a">
        <?php

        echo "user, ". $_SESSION['usr_name'];

        ?><p>


        <form role="form"  method="post" enctype="multipart/form-data">



            <input type="text" name="queid" id="queid" value="<?=$queid?>">
            <input type="text" name="quetext" id="quetext" value="<?=$quetext?>" >
            <br><br>


            <div>
                <input type="file" name="image" id="image">
            </div>

            <textarea rows="5" cols="50" style="color: #236D7F" placeholder="Enter The Answer" class="form-control" type="text" id="text" name="text"></textarea>

            <br>
            <input type="submit" name="sub" id="sub" placeholder="Enter" class="btn btn-sm">
        </form>





        <?php


        $connect=mysqli_connect("localhost","root","","uwusports");
        if(isset($_POST['sub'])) {

            $file=addslashes(file_get_contents($_FILES["image"]["tmp_name"]));



            $qid= $_POST['queid'];
            $qtext= $_POST['quetext'];
            $txt= $_POST['text'];



            $query="INSERT INTO answer(qid,question,ans,image) VALUES('$qid','$qtext','$txt','$file')";

            /* $sql = "insert into answer(qid,question,ans,image) values ('$qid','$qtext','$txt','$file')";*/

            if(mysqli_query($connect,$query)){

                echo'<script>alert("Image Insert Into Database")</script>';

                header("Location: coach.php");
            }




        }



        ?>










    </div>

</div>


<script src="js/jquery-3.1.1.js"></script>
<script src="js/bootstrap.js"></script>

</body>

</html>



<script>

    $(document).ready(function(){
       $('#sub').click(function(){

       var image_name=$('#image').val();
           if(image_name==''){

               alert("Please Select a Image");
               return  false;
           }else{
                var extension= $('#image').val().split('.').pop().toLowerCase();
               if(jQuery.inArray(extension,['gif','png','jpg','jpeg'])==-1){

                   alert("Invalid Image");
                   $('#image').val('');
                   return false;


               }

           }

       });


    });

</script>
