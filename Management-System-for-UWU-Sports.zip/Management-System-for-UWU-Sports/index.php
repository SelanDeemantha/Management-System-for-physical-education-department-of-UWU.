<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>HOME</title>
	<link rel="stylesheet" href="css/style1.css" type="text/css">
        
        <script language="JavaScript">
        <!--
        function calculateBmi() {
            var weight = document.bmiForm.weight.value
            var height = document.bmiForm.height.value
            if(weight > 0 && height > 0){
                var finalBmi = weight/(height/100*height/100)
                document.bmiForm.bmi.value = finalBmi
                if(finalBmi < 18.5){
                    document.bmiForm.meaning.value = "Below Healthy Level"
                }
                if(finalBmi > 18.5 && finalBmi < 25){
                    document.bmiForm.meaning.value = "Healthy"
                }
                if(finalBmi > 25){
                    document.bmiForm.meaning.value = "Above Healthy Level"
                }
            }
            else{
                alert("Please Fill in everything correctly")
            }
        }
        //-->
    </script>
    
</head>
<body>
	<div id="header1">
		<div id="logo">
                    <a href="index.php"> <img src="img/logo.jpg" alt="LOGO" style="width: 200px ;height: 115px"> </a>
		</div>
		<ul id="navigation">
			<li class="active">
                            <a href="index.php">Home</a>
			</li>
			<li>
				<a href="login.php">Login</a>
			</li>
		</ul>
	</div>
	<div id="adbox">
		<div>
			<div>
				<h1><br>UWU Sports</h1>
                                
				<p>
                                    <br>
					UWU SPORTS refers to a web based management system involves in the provision of overall 	information regarding the UWU sports and allow more undergraduates to join in it, whereby it will 	provide awareness regarding the services provided by the physical education department. 
				</p>
				
			</div>
		</div>
	</div>
	<div id="body">
		<div id="main">
			<h2><span>&#8220; Every champion was once a contender that refused to give up&#8221;</span></h2>
			<p>UWU SPORTS provides the information regarding the opportunities to join for sports and obtain their BMI rates by providing the facts and will be advised from the regarding the exercise equipment based on BMI rate. </p>
		</div>
		<div id="articles">
			<ul>
				<li>
					<h1>Check your BMI </h1>
        <form name="bmiForm"><table border="0" cellpadding="5">

                <tbody>
                <tr>
                    <td style="vertical-align: bottom;">Weight(kg):</td>   
                    <td ">&nbsp;&nbsp;<input type="text" name="weight" size="25"><br> </td>
                </tr>
                <tr>
                    <td style="vertical-align: bottom;">Height(cm):</td>
                    <td>&nbsp;&nbsp;<input type="text" name="height" size="25"><br></td>
                </tr>
                
                <tr>
                    <td style="vertical-align: bottom;">BMI:</td>
                    <td>&nbsp;&nbsp;<input type="text" name="bmi" size="25" readonly><br></td>
                </tr>
                <tr>
                    <td style="vertical-align: bottom;">Situation:</td>
                    <td>&nbsp;&nbsp;<input type="text" name="meaning" size="25" readonly><br></td>
                </tr>
                <tr>
                    <td></td>
                    <td>&nbsp;&nbsp;<input type="button" value="Calculate" onClick="calculateBmi()">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="reset" value="Reset" /><br></td>
                    
                </tr>
                </tbody>
            </table>
        </form>
				</li>
			</ul>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<ul>
                        <li style="width: 600px; ">
                            <h1>News</h1>
                            <?php
$con = mysqli_connect('localhost', 'root', '', 'uwusports');

?>

                            

    <?php


    if (mysqli_connect_errno()) {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }

    

    $sql = "SELECT * FROM news";

    

    $res = mysqli_query($con , $sql);

    
    ?>
                     <marquee align='left' truespeed='5'>   
    <?php
    
    while ($row = mysqli_fetch_assoc($res)):
        
            ?>
            
            <h1><?=$row['News']?></h1>
            
    <?php
    endwhile;
    ?>
            </marquee>
    </tbody>

</table>



 
                           
                        </li>
                    </ul>
		</div>
	</div>
	<div id="footer1">
		<ul id="connect">
			<li>
				<a href="http://facebook.com" target="_blank" class="facebook" title="Facebook"></a>
			</li>
			<li>
				<a href="http://twitter.com" target="_blank" class="twitter" title="Twitter"></a>
			</li>
			
			<li>
				<a href="http://googleplus.com" target="_blank" class="googleplus" title="Google+"></a>
			</li>
		</ul>
		<div id="footnote">
			<ul>
				<li class="active">
                                    <a href="index.php">Home</a>
				</li>
				
				
			</ul>
			<span>&copy; Copyright &copy; 2017. UWU SPORTS. All rights reserved.</span>
		</div>
	</div>
</body>
</html>