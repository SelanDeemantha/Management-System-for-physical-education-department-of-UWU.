<?php
$con = mysqli_connect('localhost', 'root', '', 'uwusports');

?>


<table id="mytable" class="table table-bordred table-striped" border="1">

    <thead style="background-color: sandybrown">
<tr>
            <th>Subject</th>
            <th>Description</th>
        </tr>
    </thead>

    <tbody>
    <?php


    if (mysqli_connect_errno()) {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }

    

    $sql = "SELECT * FROM notice";

    

    $res = mysqli_query($con , $sql);

    
    ?>

    <?php
    while ($row = mysqli_fetch_assoc($res)):
        
    
       echo "<tr>";
            echo "<td>".$row['noticeName']."</td>";
            echo "<td>".$row['noticeDescription']."</td>";
            echo "<td><a href=\"respond.php?id=$row[noticeID]\">Respond</a> | <a href=\"delete.php?id=$row[noticeID]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";
        
        

    
    endwhile;
    ?>

    </tbody>

</table>



 