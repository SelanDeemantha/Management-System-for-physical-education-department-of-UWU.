<?php

include_once 'config.php';

$sql="UPDATE student SET studentname='$_POST[name]',address='$_POST[address]',number='$_POST[number]',acyr='$_POST[acyr]',sport1='$_POST[sport1]',sport2='$_POST[sport2]',achivements='$_POST[achivements]' where studentid='$_POST[id]'";

if(mysqli_query($con,$sql)){

    header("refresh:1; url=stu-edit.php");


}
else{

    echo"Not Updated";

}


?>
<script src="js/jquery-3.1.1.js"></script>
<script src="js/bootstrap.js"></script>