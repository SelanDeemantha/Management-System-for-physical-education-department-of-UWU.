<?php
session_start();
$_SESSION['usr_id'];
?>
<!DOCTYPE html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Coach</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/dashbord.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/search.css">
    <link rel="stylesheet" type="text/css" href="css/student-style.css" >
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
</head>

<body class="home">


<header style="background-color: black">
    <div class="container clearfix">
        <a href="index.php"><img src="img/logo.jpg" width="175" height="120"  class="hidden-xs hidden-sm"></a>
        <ul class="nav navbar-nav navbar-right">
            <li class="dropdown" style="width: 160px; text-align: center">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button">
                    Logout<span class="caret"></span>
                </a>
                <div class="dropdown-menu" id="formLogin"  style="width: 20px">
                    <div class="row">
                        <div class="container-fluid" >
                            <form action="logout.php" method="POST">

                                <li>
                                    <button type="submit" id="btnLogin" class="btn btn-success btn-sm" style="display: block; margin: 0 auto" name="lout" value="Log Out"> Log Out </button>

                                </li>
                            </form>
                        </div>
                    </div>
                </div>
            </li>

        </ul>
    </div>
</header>



<div class="row" style="background-image: url('s.jpg');background-size: cover">
    <div class="col-lg-3" style=" width:250px;  height:500px;  background:#1A8DA9;">

        <ul >
            <li class="backg-list"><a href="coach.php">Coach_Home</a></li>

            <li class="backg-list"><a href="stu-notification.php">Special_Notices</a></li>
            <li class="backg-list"><a href="stu-bmi.php">Calculate_BMI</a></li>
            <li class="backg-list"><a href="coach-ans.php">Give_Answers</a></li>

        </ul>

    </div>
    <div class="col-lg-9">



        <?php

        include_once 'config.php';

        $records=mysqli_query($con,"SELECT queid, userid, quetext FROM question");

        ?>

        <br>
        <br>


        <table class="table">

            <thead style="background-color: lightblue">

            <tr>
                <th style="width: 50px">que_id</th>
                <th style="width: 50px">user_id</th>
                <th style="width: 500px">question</th>

                <!--<th>answer</th>-->



            </tr>
            </thead>


            <tbody>
            <?php
            while($row=mysqli_fetch_array($records)){


                //   $_SESSION['student_id'] = $row['studentid'];


                echo "<tr><form action=coach-update.php method=post>";
                echo"<td><input style='width:50px;height:30px' type=text name=queid value='".$row['queid']."'></td>";
                echo"<td><input style='width:50px;height:30px'' type=text name=userid value='".$row['userid']."'></td>";
                echo"<td><input style='width:500px;height:30px'' type=text name=quetext value='".$row['quetext']."'></td>";
                //echo"<td><input type=text name=ans value='".$row['ans']."'></td>";
                echo"<td><input type=submit placeholder='Edit' class='btn btn-sm'</td>";
                echo"</form></tr>";

            }


            ?>







            </tbody>

        </table>



        <script src="js/jquery-3.1.1.js"></script>
        <script src="js/bootstrap.js"></script>



    </div>

</div>





































</div>

</div>


<script src="js/jquery-3.1.1.js"></script>
<script src="js/bootstrap.js"></script>

</body>

</html>


