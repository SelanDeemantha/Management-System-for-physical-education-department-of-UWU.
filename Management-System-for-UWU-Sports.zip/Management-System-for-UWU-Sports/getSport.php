<?php
$con = mysqli_connect('localhost', 'root', '', 'uwusports');
?>


<table id="mytable" class="table table-bordred table-striped" border="1">

    <thead style="background-color: sandybrown">


    <tbody>
        <?php
        if (mysqli_connect_errno()) {
            echo "Failed to connect to MySQL: " . mysqli_connect_error();
        }

        $spt = $_POST["selSport"];
        $gnd = $_POST["selGender"];

        $sql = "SELECT * FROM sportlist WHERE sportName = '" . $spt . "' AND gender = '" . $gnd . "'";

        $sql1 = "SELECT * FROM student WHERE gender = '" . $gnd . "' AND sport1 = '" . $spt . "' OR gender = '" . $gnd . "' AND sport2 = '" . $spt . "' OR gender = '" . $gnd . "' AND sport3 = '" . $spt . "'  ";

        $res = mysqli_query($con, $sql);

        $res1 = mysqli_query($con, $sql1);
        
        
        ?>

        <?php
        while ($row = mysqli_fetch_assoc($res)):
           
            ?>
            <tr>
                <td>Incharge</td>
                <td> <?php echo $row['incharge']; ?> </td>
            </tr>
            <tr></tr>
            <tr>
                <td>Coach</td>
                <td> <?php echo $row['coach']; ?> </td>
            </tr>
            <tr></tr>
            <tr>
                <td>Captain</td>
                <td> <?php echo $row['captain']; ?> </td>
            </tr>
            <tr></tr>
            <tr>
                <td>Vice Captain</td>
                <td> <?php echo $row['viceCaptain']; ?> </td>
            </tr>
            

    <?php
endwhile;
?>

    </tbody>

</table>

<div class="form-group">
    <label>Players</label>
    <!--<input class="form-control"  type="text" style="border-color: black" name="dob" id="dob" value="" readonly="">-->
    <table border="1" cellpadding="1">
        <thead>
            <tr>
                <th>&nbsp;&nbsp;Name&nbsp;&nbsp;</th>
                <th>&nbsp;&nbsp;Registration No&nbsp;&nbsp;</th>

            </tr>
        </thead>
        <tbody>
<?php
while ($row1 = mysqli_fetch_assoc($res1)):
    ?>
                <tr>
                    <td>&nbsp;&nbsp;<?php echo $row1['studentname']; ?>&nbsp;&nbsp;</td>
                    <td>&nbsp;&nbsp;<?php echo $row1['regno']; ?>&nbsp;&nbsp;</td>

                </tr>
            </tbody>
    <?php
endwhile;
?>
    </table>
</div>

<!--<div id="edit12" class="modal fade" role="dialog">
    <form action="" method="post">

        <div class="modal-dialog">

            <!-- Modal content
            <div class="modal-content">
                <div class="modal-header login-header">
                    <button type="button" class="close" data-dismiss="modal">×</button>
                    <h4 class="modal-title">Edit</h4>
                </div>
                <div class="modal-body">
                    <input type="text" placeholder="Instructor" name="insName" id="insid">
                    <input type="text" placeholder="Coach" name="coachName" id="coaid">
                    <input type="text" placeholder="Captain" name="capName" id="capid">
                    <input type="text" placeholder="Vice Captain" name="vCapName" id="vcapid">
                </div>
                <div class="modal-footer">
                    <button type="button" class="cancel" data-dismiss="modal">Close</button>
                    <button type="reset" class="add-project" data-dismiss="modal">Reset</button>
                    <button onclick="myFunction3()"  id="edit" class="btn btn-success btn-sm" name="edit" value="submitp">Submit</button>
<script>
                function myFunction3() {

                    var editinfo = {
                        selSport : document.getElementById('selectSport').value,
                        selGender : document.getElementById('selectGender').value,
                        sid:$sid,
                        instr : document.getElementById('insid').value,
                        coac : document.getElementById('coaid').value,
                        capt : document.getElementById('capid').value,
                        vcapt : document.getElementById('vcapid').value
                        
                        
                    };
                    $("#sportDiv").load("editSportlist.php", editinfo);
                }
            </script>
                </div>
            </div>

        </div>
    </form>
</div>-->